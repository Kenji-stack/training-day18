// Image Service - Get images for slides
// Uses multiple sources: Unsplash, Pexels, and styled placeholders

// Unsplash Source API (no key required for demo)
const UNSPLASH_SOURCE = 'https://source.unsplash.com';

// Pexels API for high-quality images
const PEXELS_API_URL = 'https://api.pexels.com/v1/search';

/**
 * Get image for a slide from various sources
 * @param {string} prompt - Image description prompt
 * @param {string} keyword - Search keyword
 * @returns {Promise<string>} Image URL
 */
export const getSlideImage = async (prompt, keyword = '') => {
    const searchQuery = keyword || extractKeywords(prompt);

    // Try Unsplash Source first (free, no API key needed)
    try {
        const unsplashUrl = await getUnsplashImage(searchQuery);
        if (unsplashUrl) {
            return unsplashUrl;
        }
    } catch (error) {
        console.warn('Unsplash failed:', error);
    }

    // Fallback to styled placeholder
    return getStyledPlaceholder(searchQuery);
};

/**
 * Get image from Unsplash Source (no API key required)
 * @param {string} query - Search query
 * @returns {Promise<string>} Image URL
 */
const getUnsplashImage = async (query) => {
    // Clean the query for URL
    const cleanQuery = encodeURIComponent(query.slice(0, 100).replace(/[^a-zA-Z0-9\s]/g, ''));

    // Unsplash Source with random seed for variety
    const seed = Math.floor(Math.random() * 10000);
    const url = `${UNSPLASH_SOURCE}/1280x720/?${cleanQuery}&sig=${seed}`;

    // Verify the image loads
    return new Promise((resolve) => {
        const img = new Image();
        img.onload = () => resolve(url);
        img.onerror = () => resolve(null);
        img.src = url;

        // Timeout after 5 seconds
        setTimeout(() => resolve(url), 5000);
    });
};

/**
 * Extract keywords from prompt for image search
 * @param {string} prompt - Full prompt text
 * @returns {string} Keywords for search
 */
const extractKeywords = (prompt) => {
    // Remove common words and extract meaningful keywords
    const stopWords = ['a', 'an', 'the', 'is', 'are', 'was', 'were', 'be', 'been', 'being',
        'have', 'has', 'had', 'do', 'does', 'did', 'will', 'would', 'could',
        'should', 'may', 'might', 'must', 'shall', 'can', 'for', 'and', 'or',
        'but', 'in', 'on', 'at', 'to', 'of', 'with', 'by', 'from', 'about'];

    const words = prompt.toLowerCase()
        .replace(/[^a-z0-9\s]/g, ' ')
        .split(/\s+/)
        .filter(word => word.length > 2 && !stopWords.includes(word));

    // Return first 3 meaningful words
    return words.slice(0, 3).join(' ') || 'abstract technology';
};

/**
 * Search for multiple images with suggestions
 * @param {string} prompt - Primary prompt
 * @param {string} keyword - Primary keyword
 * @param {string[]} alternateKeywords - Alternate keywords
 * @returns {Promise<{primary: string, suggestions: string[]}>}
 */
export const searchImagesWithSuggestions = async (prompt, keyword = '', alternateKeywords = []) => {
    const primary = await getSlideImage(prompt, keyword);

    // Get alternate images
    const suggestions = [];
    const allKeywords = [keyword, ...alternateKeywords].filter(k => k);

    for (const kw of allKeywords.slice(0, 3)) {
        const seed = Math.floor(Math.random() * 10000);
        const cleanQuery = encodeURIComponent(kw.slice(0, 50).replace(/[^a-zA-Z0-9\s]/g, ''));
        suggestions.push(`${UNSPLASH_SOURCE}/400x300/?${cleanQuery}&sig=${seed}`);
    }

    return {
        primary,
        suggestions: suggestions.slice(0, 5)
    };
};

/**
 * Get styled placeholder image with Anti-Gravity design
 * @param {string} text - Text for placeholder
 * @returns {string} SVG data URL
 */
export const getStyledPlaceholder = (text) => {
    const shortText = (text || 'Slide').slice(0, 30);

    // Create SVG placeholder with Anti-Gravity style
    const svg = `
    <svg xmlns="http://www.w3.org/2000/svg" width="1280" height="720" viewBox="0 0 1280 720">
      <defs>
        <linearGradient id="bg" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" style="stop-color:#0f172a"/>
          <stop offset="100%" style="stop-color:#1e293b"/>
        </linearGradient>
        <linearGradient id="accent" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" style="stop-color:#8b5cf6"/>
          <stop offset="100%" style="stop-color:#ec4899"/>
        </linearGradient>
        <filter id="glow">
          <feGaussianBlur stdDeviation="3" result="coloredBlur"/>
          <feMerge>
            <feMergeNode in="coloredBlur"/>
            <feMergeNode in="SourceGraphic"/>
          </feMerge>
        </filter>
      </defs>
      <rect width="100%" height="100%" fill="url(#bg)"/>
      <!-- Decorative circles -->
      <circle cx="640" cy="360" r="200" fill="none" stroke="url(#accent)" stroke-width="1" opacity="0.2"/>
      <circle cx="640" cy="360" r="150" fill="none" stroke="url(#accent)" stroke-width="1" opacity="0.3"/>
      <circle cx="640" cy="360" r="100" fill="url(#accent)" opacity="0.1"/>
      <!-- Decorative lines -->
      <line x1="100" y1="360" x2="440" y2="360" stroke="url(#accent)" stroke-width="2" opacity="0.3"/>
      <line x1="840" y1="360" x2="1180" y2="360" stroke="url(#accent)" stroke-width="2" opacity="0.3"/>
      <!-- Center icon -->
      <g filter="url(#glow)">
        <circle cx="640" cy="340" r="40" fill="url(#accent)" opacity="0.5"/>
        <path d="M625 340 L640 325 L655 340 L640 355 Z" fill="white" opacity="0.8"/>
      </g>
      <!-- Text -->
      <text x="640" y="420" font-family="Inter, sans-serif" font-size="20" fill="#94a3b8" text-anchor="middle">
        ${escapeXml(shortText)}
      </text>
    </svg>
  `;

    return `data:image/svg+xml;base64,${btoa(unescape(encodeURIComponent(svg)))}`;
};

/**
 * Get simple placeholder image URL
 * @param {string} text - Text for placeholder
 * @returns {string} Placeholder image URL
 */
export const getPlaceholderImage = (text) => {
    const encodedText = encodeURIComponent((text || 'Slide').slice(0, 30));
    return `https://placehold.co/1280x720/1e293b/8b5cf6?text=${encodedText}`;
};

/**
 * Escape XML special characters
 * @param {string} text - Text to escape
 * @returns {string} Escaped text
 */
const escapeXml = (text) => {
    return text
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&apos;');
};
