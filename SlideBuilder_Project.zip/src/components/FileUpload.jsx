import { useState, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Upload, File, X, FileText, Image, AlertCircle, CheckCircle } from 'lucide-react';
import { extractTextFromFile } from '../services/ragService';

/**
 * FileUpload Component - Drag & Drop file upload with RAG processing
 */
const FileUpload = ({ onFilesProcessed, disabled = false }) => {
    const [isDragging, setIsDragging] = useState(false);
    const [files, setFiles] = useState([]);
    const [processing, setProcessing] = useState(false);

    const handleDragOver = useCallback((e) => {
        e.preventDefault();
        e.stopPropagation();
        if (!disabled) {
            setIsDragging(true);
        }
    }, [disabled]);

    const handleDragLeave = useCallback((e) => {
        e.preventDefault();
        e.stopPropagation();
        setIsDragging(false);
    }, []);

    const handleDrop = useCallback(async (e) => {
        e.preventDefault();
        e.stopPropagation();
        setIsDragging(false);

        if (disabled) return;

        const droppedFiles = Array.from(e.dataTransfer.files);
        await processFiles(droppedFiles);
    }, [disabled]);

    const handleFileSelect = async (e) => {
        if (disabled) return;
        const selectedFiles = Array.from(e.target.files);
        await processFiles(selectedFiles);
    };

    const processFiles = async (fileList) => {
        setProcessing(true);
        const newFiles = [];

        for (const file of fileList) {
            try {
                const result = await extractTextFromFile(file);
                newFiles.push({
                    id: Date.now() + Math.random(),
                    name: file.name,
                    size: file.size,
                    type: result.type,
                    status: 'success',
                    content: result.text,
                    file: result.file || file
                });
            } catch (error) {
                newFiles.push({
                    id: Date.now() + Math.random(),
                    name: file.name,
                    size: file.size,
                    type: 'error',
                    status: 'error',
                    error: error.message,
                    file: file
                });
            }
        }

        const updatedFiles = [...files, ...newFiles];
        setFiles(updatedFiles);
        setProcessing(false);

        if (onFilesProcessed) {
            onFilesProcessed(updatedFiles);
        }
    };

    const removeFile = (id) => {
        const updatedFiles = files.filter(f => f.id !== id);
        setFiles(updatedFiles);
        if (onFilesProcessed) {
            onFilesProcessed(updatedFiles);
        }
    };

    const getFileIcon = (type) => {
        switch (type) {
            case 'image':
                return <Image className="w-5 h-5" />;
            case 'error':
                return <AlertCircle className="w-5 h-5 text-red-400" />;
            default:
                return <FileText className="w-5 h-5" />;
        }
    };

    const formatFileSize = (bytes) => {
        if (bytes < 1024) return bytes + ' B';
        if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
        return (bytes / (1024 * 1024)).toFixed(1) + ' MB';
    };

    return (
        <div className="space-y-4">
            {/* Drop Zone */}
            <motion.div
                className={`
          relative border-2 border-dashed rounded-2xl p-8
          transition-all duration-300 cursor-pointer
          ${isDragging
                        ? 'border-ag-primary bg-ag-primary/10'
                        : 'border-white/20 hover:border-ag-primary/50 bg-white/5'
                    }
          ${disabled ? 'opacity-50 cursor-not-allowed' : ''}
        `}
                onDragOver={handleDragOver}
                onDragLeave={handleDragLeave}
                onDrop={handleDrop}
                whileHover={!disabled ? { scale: 1.01 } : {}}
                whileTap={!disabled ? { scale: 0.99 } : {}}
            >
                <input
                    type="file"
                    multiple
                    onChange={handleFileSelect}
                    className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                    disabled={disabled}
                    accept=".txt,.md,.pdf,.jpg,.jpeg,.png,.gif,.webp"
                />

                <div className="flex flex-col items-center text-center">
                    <motion.div
                        className={`
              w-16 h-16 rounded-full flex items-center justify-center mb-4
              ${isDragging ? 'bg-ag-primary' : 'bg-ag-surface'}
            `}
                        animate={isDragging ? { scale: 1.1 } : { scale: 1 }}
                    >
                        <Upload className={`w-8 h-8 ${isDragging ? 'text-white' : 'text-ag-primary'}`} />
                    </motion.div>

                    <h3 className="text-lg font-semibold text-white mb-2">
                        {processing ? '処理中...' : 'ファイルをドラッグ＆ドロップ'}
                    </h3>
                    <p className="text-sm text-gray-400">
                        または <span className="text-ag-primary font-medium">クリックして選択</span>
                    </p>
                    <p className="text-xs text-gray-500 mt-2">
                        対応形式: テキスト (.txt, .md), PDF, 画像 (.jpg, .png, .webp)
                    </p>
                </div>
            </motion.div>

            {/* File List */}
            <AnimatePresence>
                {files.length > 0 && (
                    <motion.div
                        initial={{ opacity: 0, height: 0 }}
                        animate={{ opacity: 1, height: 'auto' }}
                        exit={{ opacity: 0, height: 0 }}
                        className="space-y-2"
                    >
                        <h4 className="text-sm font-medium text-gray-400">
                            アップロード済みファイル ({files.length})
                        </h4>

                        {files.map((file) => (
                            <motion.div
                                key={file.id}
                                initial={{ opacity: 0, x: -20 }}
                                animate={{ opacity: 1, x: 0 }}
                                exit={{ opacity: 0, x: 20 }}
                                className={`
                  flex items-center gap-3 p-3 rounded-xl
                  ${file.status === 'error' ? 'bg-red-900/20' : 'bg-ag-surface'}
                `}
                            >
                                <div className={`
                  w-10 h-10 rounded-lg flex items-center justify-center
                  ${file.status === 'error' ? 'bg-red-500/20' : 'bg-ag-primary/20'}
                `}>
                                    {getFileIcon(file.type)}
                                </div>

                                <div className="flex-1 min-w-0">
                                    <p className="text-sm font-medium text-white truncate">
                                        {file.name}
                                    </p>
                                    <p className="text-xs text-gray-400">
                                        {file.status === 'error'
                                            ? file.error
                                            : `${formatFileSize(file.size)} • ${file.type}`
                                        }
                                    </p>
                                </div>

                                <div className="flex items-center gap-2">
                                    {file.status === 'success' && (
                                        <CheckCircle className="w-5 h-5 text-green-400" />
                                    )}
                                    <button
                                        onClick={() => removeFile(file.id)}
                                        className="p-1 rounded-lg hover:bg-white/10 transition-colors"
                                        disabled={disabled}
                                    >
                                        <X className="w-4 h-4 text-gray-400" />
                                    </button>
                                </div>
                            </motion.div>
                        ))}
                    </motion.div>
                )}
            </AnimatePresence>
        </div>
    );
};

export default FileUpload;
