import { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
    Send, Paperclip, Settings, Sparkles, Loader2,
    Users, Layers, X, ChevronDown
} from 'lucide-react';
import FileUpload from './FileUpload';

/**
 * ChatInterface Component - Chat-style prompt input for slide generation
 */
const ChatInterface = ({
    onGenerate,
    isGenerating = false,
    generationStatus = ''
}) => {
    const [prompt, setPrompt] = useState('');
    const [files, setFiles] = useState([]);
    const [showSettings, setShowSettings] = useState(false);
    const [showFileUpload, setShowFileUpload] = useState(false);
    const [targetAudience, setTargetAudience] = useState('一般');
    const [slideCount, setSlideCount] = useState(5);
    const textareaRef = useRef(null);

    const audienceOptions = [
        { value: '一般', label: '一般' },
        { value: '学生・若者', label: '学生・若者' },
        { value: '専門家', label: '専門家' },
        { value: 'ビジネスパーソン', label: 'ビジネスパーソン' },
        { value: '技術者', label: '技術者' }
    ];

    // Auto-resize textarea
    useEffect(() => {
        if (textareaRef.current) {
            textareaRef.current.style.height = 'auto';
            textareaRef.current.style.height = Math.min(textareaRef.current.scrollHeight, 200) + 'px';
        }
    }, [prompt]);

    const handleSubmit = () => {
        if (!prompt.trim() && files.length === 0) return;
        if (isGenerating) return;

        onGenerate({
            prompt: prompt.trim(),
            files,
            targetAudience,
            slideCount
        });
    };

    const handleKeyDown = (e) => {
        if (e.key === 'Enter' && !e.shiftKey) {
            e.preventDefault();
            handleSubmit();
        }
    };

    const handleFilesProcessed = (processedFiles) => {
        setFiles(processedFiles);
    };

    return (
        <div className="w-full max-w-4xl mx-auto space-y-4">
            {/* File Upload Modal */}
            <AnimatePresence>
                {showFileUpload && (
                    <motion.div
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: 20 }}
                        className="bg-ag-surface rounded-2xl p-6 border border-white/10"
                    >
                        <div className="flex items-center justify-between mb-4">
                            <h3 className="text-lg font-semibold text-white">参照ファイル</h3>
                            <button
                                onClick={() => setShowFileUpload(false)}
                                className="p-2 rounded-lg hover:bg-white/10 text-gray-400"
                            >
                                <X className="w-5 h-5" />
                            </button>
                        </div>
                        <FileUpload
                            onFilesProcessed={handleFilesProcessed}
                            disabled={isGenerating}
                        />
                    </motion.div>
                )}
            </AnimatePresence>

            {/* Settings Panel */}
            <AnimatePresence>
                {showSettings && (
                    <motion.div
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: 20 }}
                        className="bg-ag-surface rounded-2xl p-6 border border-white/10"
                    >
                        <div className="flex items-center justify-between mb-6">
                            <h3 className="text-lg font-semibold text-white">生成設定</h3>
                            <button
                                onClick={() => setShowSettings(false)}
                                className="p-2 rounded-lg hover:bg-white/10 text-gray-400"
                            >
                                <X className="w-5 h-5" />
                            </button>
                        </div>

                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                            {/* Target Audience */}
                            <div>
                                <label className="flex items-center gap-2 text-sm font-medium text-gray-400 mb-2">
                                    <Users className="w-4 h-4" />
                                    ターゲットオーディエンス
                                </label>
                                <div className="relative">
                                    <select
                                        value={targetAudience}
                                        onChange={(e) => setTargetAudience(e.target.value)}
                                        className="w-full bg-ag-dark border border-white/20 rounded-xl px-4 py-3 text-white appearance-none focus:outline-none focus:border-ag-primary"
                                    >
                                        {audienceOptions.map(opt => (
                                            <option key={opt.value} value={opt.value}>{opt.label}</option>
                                        ))}
                                    </select>
                                    <ChevronDown className="absolute right-4 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400 pointer-events-none" />
                                </div>
                            </div>

                            {/* Slide Count */}
                            <div>
                                <label className="flex items-center gap-2 text-sm font-medium text-gray-400 mb-2">
                                    <Layers className="w-4 h-4" />
                                    目標スライド枚数
                                </label>
                                <div className="flex items-center gap-4">
                                    <input
                                        type="range"
                                        min="3"
                                        max="15"
                                        value={slideCount}
                                        onChange={(e) => setSlideCount(parseInt(e.target.value))}
                                        className="flex-1 accent-ag-primary"
                                    />
                                    <span className="text-white font-medium w-8 text-center">
                                        {slideCount}
                                    </span>
                                </div>
                            </div>
                        </div>
                    </motion.div>
                )}
            </AnimatePresence>

            {/* File Badges */}
            {files.length > 0 && !showFileUpload && (
                <div className="flex flex-wrap gap-2">
                    {files.map((file) => (
                        <div
                            key={file.id}
                            className="flex items-center gap-2 px-3 py-1.5 bg-ag-surface rounded-full text-sm"
                        >
                            <Paperclip className="w-3 h-3 text-ag-primary" />
                            <span className="text-gray-300 max-w-[150px] truncate">{file.name}</span>
                            <button
                                onClick={() => setFiles(files.filter(f => f.id !== file.id))}
                                className="text-gray-500 hover:text-white"
                            >
                                <X className="w-3 h-3" />
                            </button>
                        </div>
                    ))}
                </div>
            )}

            {/* Main Input Area */}
            <div className="relative">
                <div className="bg-ag-surface rounded-2xl border border-white/10 overflow-hidden focus-within:border-ag-primary/50 transition-colors">
                    {/* Action Buttons */}
                    <div className="flex items-center gap-1 px-4 pt-3">
                        <button
                            onClick={() => setShowFileUpload(!showFileUpload)}
                            className={`p-2 rounded-lg transition-colors ${showFileUpload || files.length > 0
                                    ? 'bg-ag-primary/20 text-ag-primary'
                                    : 'hover:bg-white/10 text-gray-400'
                                }`}
                            disabled={isGenerating}
                            title="ファイルを追加"
                        >
                            <Paperclip className="w-5 h-5" />
                        </button>
                        <button
                            onClick={() => setShowSettings(!showSettings)}
                            className={`p-2 rounded-lg transition-colors ${showSettings
                                    ? 'bg-ag-primary/20 text-ag-primary'
                                    : 'hover:bg-white/10 text-gray-400'
                                }`}
                            disabled={isGenerating}
                            title="設定"
                        >
                            <Settings className="w-5 h-5" />
                        </button>
                        <div className="flex-1" />
                        <span className="text-xs text-gray-500">
                            {targetAudience} • {slideCount}枚
                        </span>
                    </div>

                    {/* Text Input */}
                    <div className="px-4 py-3">
                        <textarea
                            ref={textareaRef}
                            value={prompt}
                            onChange={(e) => setPrompt(e.target.value)}
                            onKeyDown={handleKeyDown}
                            placeholder="スライドの内容を説明してください... (例: 「機械学習の基礎について初心者向けに解説」)"
                            className="w-full bg-transparent text-white placeholder-gray-500 resize-none focus:outline-none min-h-[24px] max-h-[200px]"
                            rows={1}
                            disabled={isGenerating}
                        />
                    </div>

                    {/* Submit Button */}
                    <div className="flex items-center justify-between px-4 pb-3">
                        <p className="text-xs text-gray-500">
                            Shift + Enter で改行
                        </p>
                        <button
                            onClick={handleSubmit}
                            disabled={isGenerating || (!prompt.trim() && files.length === 0)}
                            className={`
                flex items-center gap-2 px-5 py-2.5 rounded-xl font-medium
                transition-all duration-200
                ${isGenerating || (!prompt.trim() && files.length === 0)
                                    ? 'bg-gray-700 text-gray-500 cursor-not-allowed'
                                    : 'bg-gradient-to-r from-ag-primary to-ag-secondary text-white hover:shadow-lg hover:shadow-ag-primary/25'
                                }
              `}
                        >
                            {isGenerating ? (
                                <>
                                    <Loader2 className="w-4 h-4 animate-spin" />
                                    生成中...
                                </>
                            ) : (
                                <>
                                    <Sparkles className="w-4 h-4" />
                                    スライド生成
                                </>
                            )}
                        </button>
                    </div>
                </div>

                {/* Generation Status */}
                <AnimatePresence>
                    {isGenerating && generationStatus && (
                        <motion.div
                            initial={{ opacity: 0, y: 10 }}
                            animate={{ opacity: 1, y: 0 }}
                            exit={{ opacity: 0 }}
                            className="absolute -bottom-8 left-0 right-0 text-center"
                        >
                            <span className="text-sm text-gray-400">
                                {generationStatus}
                            </span>
                        </motion.div>
                    )}
                </AnimatePresence>
            </div>

            {/* Prompt Suggestions */}
            {!prompt && !isGenerating && (
                <div className="flex flex-wrap gap-2 justify-center">
                    {[
                        '製品紹介のプレゼンを作成',
                        '技術解説スライドを作成',
                        '会議のアジェンダを作成',
                        'プロジェクト報告書を作成'
                    ].map((suggestion) => (
                        <button
                            key={suggestion}
                            onClick={() => setPrompt(suggestion)}
                            className="px-4 py-2 bg-ag-surface/50 rounded-full text-sm text-gray-400 hover:text-white hover:bg-ag-surface transition-colors"
                        >
                            {suggestion}
                        </button>
                    ))}
                </div>
            )}
        </div>
    );
};

export default ChatInterface;
