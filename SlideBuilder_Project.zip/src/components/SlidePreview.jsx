import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
    ChevronLeft, ChevronRight, Edit3, Save, X, Download,
    Maximize2, Image as ImageIcon, BarChart3, ArrowRight
} from 'lucide-react';
import {
    BarChart, Bar, LineChart, Line, PieChart, Pie, Cell,
    XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer
} from 'recharts';
import { exportToPPTX } from '../services/exportService';

// Chart colors
const CHART_COLORS = ['#8b5cf6', '#ec4899', '#06b6d4', '#10b981', '#f59e0b'];

/**
 * SlidePreview Component - Preview and edit slides with chart rendering
 */
const SlidePreview = ({ slidesData, onEdit, onClose }) => {
    const [currentIndex, setCurrentIndex] = useState(0);
    const [isEditing, setIsEditing] = useState(false);
    const [editedSlides, setEditedSlides] = useState([]);
    const [isExporting, setIsExporting] = useState(false);
    const [selectedImageIndex, setSelectedImageIndex] = useState({});
    const [isFullscreen, setIsFullscreen] = useState(false);

    useEffect(() => {
        if (slidesData?.slides) {
            setEditedSlides([...slidesData.slides]);
        }
    }, [slidesData]);

    const currentSlide = editedSlides[currentIndex] || {};

    const nextSlide = () => {
        if (currentIndex < editedSlides.length - 1) {
            setCurrentIndex(prev => prev + 1);
        }
    };

    const prevSlide = () => {
        if (currentIndex > 0) {
            setCurrentIndex(prev => prev - 1);
        }
    };

    const handleContentChange = (field, value) => {
        const updated = [...editedSlides];
        updated[currentIndex] = {
            ...updated[currentIndex],
            [field]: value
        };
        setEditedSlides(updated);
    };

    const saveChanges = () => {
        setIsEditing(false);
        if (onEdit) {
            onEdit({ ...slidesData, slides: editedSlides });
        }
    };

    const handleExport = async () => {
        setIsExporting(true);
        try {
            await exportToPPTX({
                ...slidesData,
                slides: editedSlides.map((slide, idx) => ({
                    ...slide,
                    slideType: slide.type || slide.slideType,
                    slideTitle: slide.title || slide.slideTitle,
                    mainContent: slide.content || slide.mainContent
                }))
            });
        } catch (error) {
            console.error('Export error:', error);
            alert('エクスポートに失敗しました: ' + error.message);
        }
        setIsExporting(false);
    };

    const selectAlternateImage = (slideIndex, imageIndex) => {
        const slide = editedSlides[slideIndex];
        if (slide.suggestedImages && slide.suggestedImages[imageIndex]) {
            const updated = [...editedSlides];
            updated[slideIndex] = {
                ...updated[slideIndex],
                imageUrl: slide.suggestedImages[imageIndex]
            };
            setEditedSlides(updated);
            setSelectedImageIndex({ ...selectedImageIndex, [slideIndex]: imageIndex });
        }
    };

    // Render chart based on chartData
    const renderChart = (chartData) => {
        if (!chartData || !chartData.data) return null;

        switch (chartData.type) {
            case 'BAR_CHART':
                return (
                    <ResponsiveContainer width="100%" height={200}>
                        <BarChart data={chartData.data}>
                            <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                            <XAxis dataKey="label" stroke="#94a3b8" fontSize={12} />
                            <YAxis stroke="#94a3b8" fontSize={12} />
                            <Tooltip
                                contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #334155' }}
                                labelStyle={{ color: '#fff' }}
                            />
                            <Bar dataKey="value" fill="#8b5cf6" radius={[4, 4, 0, 0]} />
                        </BarChart>
                    </ResponsiveContainer>
                );

            case 'LINE_CHART':
                return (
                    <ResponsiveContainer width="100%" height={200}>
                        <LineChart data={chartData.data}>
                            <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                            <XAxis dataKey="label" stroke="#94a3b8" fontSize={12} />
                            <YAxis stroke="#94a3b8" fontSize={12} />
                            <Tooltip
                                contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #334155' }}
                            />
                            <Line
                                type="monotone"
                                dataKey="value"
                                stroke="#8b5cf6"
                                strokeWidth={2}
                                dot={{ fill: '#8b5cf6' }}
                            />
                        </LineChart>
                    </ResponsiveContainer>
                );

            case 'PIE_CHART':
                return (
                    <ResponsiveContainer width="100%" height={200}>
                        <PieChart>
                            <Pie
                                data={chartData.data}
                                dataKey="value"
                                nameKey="label"
                                cx="50%"
                                cy="50%"
                                outerRadius={80}
                                label={({ label }) => label}
                            >
                                {chartData.data.map((_, index) => (
                                    <Cell key={index} fill={CHART_COLORS[index % CHART_COLORS.length]} />
                                ))}
                            </Pie>
                            <Tooltip />
                        </PieChart>
                    </ResponsiveContainer>
                );

            case 'FLOW_CHART':
                return (
                    <div className="flex items-center justify-center gap-2 flex-wrap p-4">
                        {chartData.data.map((item, index) => (
                            <div key={index} className="flex items-center gap-2">
                                <div className="bg-ag-primary/20 border border-ag-primary rounded-lg px-4 py-2 text-sm text-white">
                                    {item.label || item}
                                </div>
                                {index < chartData.data.length - 1 && (
                                    <ArrowRight className="w-5 h-5 text-ag-primary" />
                                )}
                            </div>
                        ))}
                    </div>
                );

            case 'TABLE':
                return (
                    <div className="overflow-x-auto">
                        <table className="w-full text-sm">
                            <thead>
                                <tr className="border-b border-white/20">
                                    {Object.keys(chartData.data[0] || {}).map((key) => (
                                        <th key={key} className="px-3 py-2 text-left text-gray-400 font-medium">
                                            {key}
                                        </th>
                                    ))}
                                </tr>
                            </thead>
                            <tbody>
                                {chartData.data.map((row, i) => (
                                    <tr key={i} className="border-b border-white/10">
                                        {Object.values(row).map((value, j) => (
                                            <td key={j} className="px-3 py-2 text-white">
                                                {value}
                                            </td>
                                        ))}
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                );

            default:
                return null;
        }
    };

    // Render slide content based on type
    const renderSlideContent = () => {
        const slideType = currentSlide.type || currentSlide.slideType;
        const title = currentSlide.title || currentSlide.slideTitle || '';
        const content = currentSlide.content || currentSlide.mainContent || '';
        const imageUrl = currentSlide.imageUrl || '';

        switch (slideType) {
            case 'TITLE':
                return (
                    <div className="flex flex-col items-center justify-center h-full text-center px-8">
                        {isEditing ? (
                            <>
                                <input
                                    type="text"
                                    value={title}
                                    onChange={(e) => handleContentChange('title', e.target.value)}
                                    className="text-4xl md:text-5xl font-bold bg-transparent border-b-2 border-ag-primary text-white text-center w-full mb-6 focus:outline-none"
                                    placeholder="タイトルを入力"
                                />
                                <textarea
                                    value={content}
                                    onChange={(e) => handleContentChange('content', e.target.value)}
                                    className="text-xl bg-transparent border border-white/20 rounded-lg text-gray-300 text-center w-full p-4 focus:outline-none focus:border-ag-primary resize-none"
                                    rows={2}
                                    placeholder="サブタイトルを入力"
                                />
                            </>
                        ) : (
                            <>
                                <h1 className="text-4xl md:text-5xl font-bold text-white mb-6 bg-gradient-to-r from-ag-primary to-ag-secondary bg-clip-text text-transparent">
                                    {title}
                                </h1>
                                <p className="text-xl text-gray-300">{content}</p>
                            </>
                        )}
                    </div>
                );

            case 'CONTENT_LEFT':
            case 'CONTENT_RIGHT':
                const isLeft = slideType === 'CONTENT_LEFT';
                return (
                    <div className={`grid grid-cols-1 md:grid-cols-2 gap-6 h-full p-6 ${!isLeft ? 'direction-rtl' : ''}`}>
                        <div className={`flex flex-col ${!isLeft ? 'md:order-2' : ''}`}>
                            {isEditing ? (
                                <>
                                    <input
                                        type="text"
                                        value={title}
                                        onChange={(e) => handleContentChange('title', e.target.value)}
                                        className="text-2xl font-bold bg-transparent border-b border-ag-primary text-white mb-4 focus:outline-none"
                                    />
                                    <textarea
                                        value={content}
                                        onChange={(e) => handleContentChange('content', e.target.value)}
                                        className="flex-1 bg-transparent border border-white/20 rounded-lg text-gray-300 p-4 focus:outline-none focus:border-ag-primary resize-none"
                                    />
                                </>
                            ) : (
                                <>
                                    <h2 className="text-2xl font-bold text-white mb-4">{title}</h2>
                                    <p className="text-gray-300 whitespace-pre-wrap">{content}</p>
                                </>
                            )}
                            {currentSlide.chartData && (
                                <div className="mt-4">
                                    {renderChart(currentSlide.chartData)}
                                </div>
                            )}
                        </div>
                        <div className={`relative rounded-xl overflow-hidden ${!isLeft ? 'md:order-1' : ''}`}>
                            {imageUrl ? (
                                <img
                                    src={imageUrl}
                                    alt={title}
                                    className="w-full h-full object-cover"
                                    onError={(e) => {
                                        e.target.src = `https://placehold.co/800x600/1e293b/8b5cf6?text=${encodeURIComponent(title.slice(0, 20))}`;
                                    }}
                                />
                            ) : (
                                <div className="w-full h-full bg-ag-surface flex items-center justify-center">
                                    <ImageIcon className="w-16 h-16 text-gray-600" />
                                </div>
                            )}
                            {/* Image suggestions */}
                            {currentSlide.suggestedImages && currentSlide.suggestedImages.length > 0 && (
                                <div className="absolute bottom-2 left-2 right-2 flex gap-1 overflow-x-auto">
                                    {currentSlide.suggestedImages.map((img, idx) => (
                                        <button
                                            key={idx}
                                            onClick={() => selectAlternateImage(currentIndex, idx)}
                                            className="w-12 h-12 rounded border-2 border-white/20 hover:border-ag-primary overflow-hidden flex-shrink-0"
                                        >
                                            <img src={img} alt="" className="w-full h-full object-cover" />
                                        </button>
                                    ))}
                                </div>
                            )}
                        </div>
                    </div>
                );

            case 'BULLETS':
                const bullets = content.split('\n').filter(b => b.trim());
                return (
                    <div className="flex flex-col h-full p-6">
                        {isEditing ? (
                            <>
                                <input
                                    type="text"
                                    value={title}
                                    onChange={(e) => handleContentChange('title', e.target.value)}
                                    className="text-2xl font-bold bg-transparent border-b border-ag-primary text-white mb-6 focus:outline-none"
                                />
                                <textarea
                                    value={content}
                                    onChange={(e) => handleContentChange('content', e.target.value)}
                                    className="flex-1 bg-transparent border border-white/20 rounded-lg text-gray-300 p-4 focus:outline-none focus:border-ag-primary resize-none"
                                    placeholder="箇条書き（改行で区切る）"
                                />
                            </>
                        ) : (
                            <>
                                <h2 className="text-2xl font-bold text-white mb-6">{title}</h2>
                                <ul className="space-y-4">
                                    {bullets.map((bullet, idx) => (
                                        <motion.li
                                            key={idx}
                                            initial={{ opacity: 0, x: -20 }}
                                            animate={{ opacity: 1, x: 0 }}
                                            transition={{ delay: idx * 0.1 }}
                                            className="flex items-start gap-3"
                                        >
                                            <span className="w-2 h-2 rounded-full bg-ag-primary mt-2 flex-shrink-0" />
                                            <span className="text-gray-300">{bullet.replace(/^[-•]\s*/, '')}</span>
                                        </motion.li>
                                    ))}
                                </ul>
                            </>
                        )}
                    </div>
                );

            case 'COMPARE':
                const parts = content.split('\n\n');
                return (
                    <div className="flex flex-col h-full p-6">
                        <h2 className="text-2xl font-bold text-white mb-6 text-center">{title}</h2>
                        <div className="grid grid-cols-2 gap-6 flex-1">
                            <div className="bg-ag-surface rounded-xl p-4 border-2 border-ag-primary">
                                {isEditing ? (
                                    <textarea
                                        value={parts[0] || ''}
                                        onChange={(e) => handleContentChange('content', e.target.value + '\n\n' + (parts[1] || ''))}
                                        className="w-full h-full bg-transparent text-gray-300 resize-none focus:outline-none"
                                    />
                                ) : (
                                    <p className="text-gray-300 whitespace-pre-wrap">{parts[0]}</p>
                                )}
                            </div>
                            <div className="bg-ag-surface rounded-xl p-4 border-2 border-ag-secondary">
                                {isEditing ? (
                                    <textarea
                                        value={parts[1] || ''}
                                        onChange={(e) => handleContentChange('content', (parts[0] || '') + '\n\n' + e.target.value)}
                                        className="w-full h-full bg-transparent text-gray-300 resize-none focus:outline-none"
                                    />
                                ) : (
                                    <p className="text-gray-300 whitespace-pre-wrap">{parts[1]}</p>
                                )}
                            </div>
                        </div>
                    </div>
                );

            case 'STEPS':
                const steps = content.split('\n').filter(s => s.trim());
                return (
                    <div className="flex flex-col h-full p-6">
                        <h2 className="text-2xl font-bold text-white mb-6">{title}</h2>
                        {isEditing ? (
                            <textarea
                                value={content}
                                onChange={(e) => handleContentChange('content', e.target.value)}
                                className="flex-1 bg-transparent border border-white/20 rounded-lg text-gray-300 p-4 focus:outline-none focus:border-ag-primary resize-none"
                            />
                        ) : (
                            <div className="space-y-4">
                                {steps.map((step, idx) => (
                                    <motion.div
                                        key={idx}
                                        initial={{ opacity: 0, y: 20 }}
                                        animate={{ opacity: 1, y: 0 }}
                                        transition={{ delay: idx * 0.15 }}
                                        className="flex items-center gap-4"
                                    >
                                        <div className="w-10 h-10 rounded-full bg-gradient-to-br from-ag-primary to-ag-secondary flex items-center justify-center text-white font-bold flex-shrink-0">
                                            {idx + 1}
                                        </div>
                                        <p className="text-gray-300">{step.replace(/^\d+\.\s*/, '')}</p>
                                    </motion.div>
                                ))}
                            </div>
                        )}
                    </div>
                );

            case 'QUOTE':
                return (
                    <div className="flex flex-col items-center justify-center h-full p-8 text-center">
                        <div className="text-6xl text-ag-primary mb-4">"</div>
                        {isEditing ? (
                            <textarea
                                value={content}
                                onChange={(e) => handleContentChange('content', e.target.value)}
                                className="text-2xl italic bg-transparent border border-white/20 rounded-lg text-white text-center w-full p-4 focus:outline-none focus:border-ag-primary resize-none"
                            />
                        ) : (
                            <p className="text-2xl italic text-white max-w-3xl">{content}</p>
                        )}
                        <p className="text-gray-400 mt-6">— {title}</p>
                    </div>
                );

            default:
                return (
                    <div className="flex flex-col h-full p-6">
                        <h2 className="text-2xl font-bold text-white mb-4">{title}</h2>
                        <p className="text-gray-300">{content}</p>
                    </div>
                );
        }
    };

    if (!slidesData || !editedSlides.length) {
        return null;
    }

    return (
        <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className={`
        ${isFullscreen
                    ? 'fixed inset-0 z-50 bg-ag-dark'
                    : 'relative'}
      `}
        >
            {/* Header */}
            <div className="flex items-center justify-between p-4 border-b border-white/10">
                <div className="flex items-center gap-4">
                    <h2 className="text-lg font-semibold text-white">
                        {slidesData.title || 'プレゼンテーション'}
                    </h2>
                    <span className="text-sm text-gray-400">
                        {currentIndex + 1} / {editedSlides.length}
                    </span>
                </div>

                <div className="flex items-center gap-2">
                    {isEditing ? (
                        <>
                            <button
                                onClick={saveChanges}
                                className="flex items-center gap-2 px-4 py-2 bg-ag-primary rounded-lg text-white hover:bg-ag-primary/80 transition-colors"
                            >
                                <Save className="w-4 h-4" />
                                保存
                            </button>
                            <button
                                onClick={() => {
                                    setIsEditing(false);
                                    setEditedSlides([...slidesData.slides]);
                                }}
                                className="p-2 rounded-lg hover:bg-white/10 text-gray-400"
                            >
                                <X className="w-5 h-5" />
                            </button>
                        </>
                    ) : (
                        <>
                            <button
                                onClick={() => setIsEditing(true)}
                                className="flex items-center gap-2 px-4 py-2 bg-ag-surface rounded-lg text-white hover:bg-white/10 transition-colors"
                            >
                                <Edit3 className="w-4 h-4" />
                                編集
                            </button>
                            <button
                                onClick={handleExport}
                                disabled={isExporting}
                                className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-ag-primary to-ag-secondary rounded-lg text-white hover:opacity-90 transition-opacity disabled:opacity-50"
                            >
                                <Download className="w-4 h-4" />
                                {isExporting ? 'エクスポート中...' : 'PowerPoint'}
                            </button>
                            <button
                                onClick={() => setIsFullscreen(!isFullscreen)}
                                className="p-2 rounded-lg hover:bg-white/10 text-gray-400"
                            >
                                <Maximize2 className="w-5 h-5" />
                            </button>
                        </>
                    )}
                    {onClose && (
                        <button
                            onClick={onClose}
                            className="p-2 rounded-lg hover:bg-white/10 text-gray-400"
                        >
                            <X className="w-5 h-5" />
                        </button>
                    )}
                </div>
            </div>

            {/* Slide Preview */}
            <div className="relative aspect-video bg-ag-dark mx-auto max-w-5xl my-4 rounded-xl overflow-hidden border border-white/10">
                <AnimatePresence mode="wait">
                    <motion.div
                        key={currentIndex}
                        initial={{ opacity: 0, x: 50 }}
                        animate={{ opacity: 1, x: 0 }}
                        exit={{ opacity: 0, x: -50 }}
                        transition={{ duration: 0.2 }}
                        className="absolute inset-0"
                    >
                        {renderSlideContent()}
                    </motion.div>
                </AnimatePresence>

                {/* Navigation */}
                <button
                    onClick={prevSlide}
                    disabled={currentIndex === 0}
                    className="absolute left-4 top-1/2 -translate-y-1/2 p-2 rounded-full bg-black/50 text-white hover:bg-black/70 disabled:opacity-30 disabled:cursor-not-allowed transition-all"
                >
                    <ChevronLeft className="w-6 h-6" />
                </button>
                <button
                    onClick={nextSlide}
                    disabled={currentIndex === editedSlides.length - 1}
                    className="absolute right-4 top-1/2 -translate-y-1/2 p-2 rounded-full bg-black/50 text-white hover:bg-black/70 disabled:opacity-30 disabled:cursor-not-allowed transition-all"
                >
                    <ChevronRight className="w-6 h-6" />
                </button>
            </div>

            {/* Slide Thumbnails */}
            <div className="flex gap-2 overflow-x-auto p-4 mx-auto max-w-5xl">
                {editedSlides.map((slide, idx) => (
                    <button
                        key={idx}
                        onClick={() => setCurrentIndex(idx)}
                        className={`
              flex-shrink-0 w-24 h-14 rounded-lg border-2 overflow-hidden
              ${idx === currentIndex
                                ? 'border-ag-primary'
                                : 'border-white/20 hover:border-white/40'}
              transition-colors
            `}
                    >
                        <div className="w-full h-full bg-ag-surface flex items-center justify-center">
                            <span className="text-xs text-gray-400">{idx + 1}</span>
                        </div>
                    </button>
                ))}
            </div>
        </motion.div>
    );
};

export default SlidePreview;
