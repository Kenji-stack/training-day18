import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Presentation, Sparkles, History, Settings, LogIn, User } from 'lucide-react';
import ChatInterface from './components/ChatInterface';
import SlidePreview from './components/SlidePreview';
import { generateSlides, describeImage } from './services/geminiService';
import { processFilesForRAG } from './services/ragService';
import { getSlideImage, getStyledPlaceholder } from './services/imageService';
import {
  initializeFirebase,
  signInAnonymouslyUser,
  onAuthChange,
  saveSlidesDeck,
  getAllSlidesDecks
} from './lib/firebase';

function App() {
  const [user, setUser] = useState(null);
  const [slidesData, setSlidesData] = useState(null);
  const [isGenerating, setIsGenerating] = useState(false);
  const [generationStatus, setGenerationStatus] = useState('');
  const [savedDecks, setSavedDecks] = useState([]);
  const [showHistory, setShowHistory] = useState(false);
  const [apiKeyInput, setApiKeyInput] = useState('');
  const [showApiKeyModal, setShowApiKeyModal] = useState(false);

  // Initialize Firebase and auth
  useEffect(() => {
    initializeFirebase();

    const unsubscribe = onAuthChange((authUser) => {
      setUser(authUser);
      if (authUser) {
        loadSavedDecks(authUser.uid);
      }
    });

    // Auto sign in anonymously if not signed in
    const autoSignIn = async () => {
      const currentUser = await signInAnonymouslyUser();
      if (currentUser) {
        setUser(currentUser);
      }
    };
    autoSignIn();

    return () => unsubscribe();
  }, []);

  const loadSavedDecks = async (userId) => {
    const decks = await getAllSlidesDecks(userId);
    setSavedDecks(decks);
  };

  const handleGenerate = async ({ prompt, files, targetAudience, slideCount }) => {
    setIsGenerating(true);
    setSlidesData(null);

    try {
      // Step 1: Process files for RAG
      setGenerationStatus('ファイルを処理中...');
      const { context, images } = await processFilesForRAG(
        files.map(f => f.file).filter(Boolean)
      );

      // Step 2: Process images with Gemini Vision
      let imageDescriptions = '';
      if (images.length > 0) {
        setGenerationStatus('画像を解析中...');
        for (const image of images) {
          const description = await describeImage(image);
          if (description) {
            imageDescriptions += `\n\n画像「${image.name}」の内容:\n${description}`;
          }
        }
      }

      const fullContext = context + imageDescriptions;

      // Step 3: Generate slides with Gemini
      setGenerationStatus('スライドを生成中...');
      const generated = await generateSlides(
        prompt,
        fullContext,
        images,
        slideCount,
        targetAudience
      );

      // Step 4: Generate images for each slide
      setGenerationStatus('画像を生成中...');
      const slidesWithImages = await Promise.all(
        generated.slides.map(async (slide, index) => {
          // Use imagePrompt for Gemini image generation
          const imagePrompt = slide.imagePrompt || slide.imageKeyword || slide.title || '';

          if (imagePrompt) {
            setGenerationStatus(`画像を生成中... (${index + 1}/${generated.slides.length})`);
            try {
              const imageUrl = await getSlideImage(imagePrompt, slide.imageKeyword || slide.title);
              return {
                ...slide,
                imageUrl: imageUrl || getStyledPlaceholder(slide.title || 'Slide'),
                suggestedImages: []
              };
            } catch (error) {
              console.warn('Image generation failed for slide:', index, error);
              return {
                ...slide,
                imageUrl: getStyledPlaceholder(slide.title || 'Slide'),
                suggestedImages: []
              };
            }
          }
          return {
            ...slide,
            imageUrl: getStyledPlaceholder(slide.title || 'Slide')
          };
        })
      );

      const finalData = {
        title: generated.title || 'プレゼンテーション',
        slides: slidesWithImages,
        targetAudience,
        createdAt: new Date().toISOString()
      };

      setSlidesData(finalData);

      // Save to Firestore
      if (user) {
        setGenerationStatus('保存中...');
        await saveSlidesDeck(user.uid, finalData);
        await loadSavedDecks(user.uid);
      }

      setGenerationStatus('');
    } catch (error) {
      console.error('Generation error:', error);
      setGenerationStatus('');
      alert('スライド生成に失敗しました: ' + error.message);
    }

    setIsGenerating(false);
  };

  const handleEditSlides = (updatedData) => {
    setSlidesData(updatedData);
  };

  const handleClosePreview = () => {
    setSlidesData(null);
  };

  const loadDeck = (deck) => {
    setSlidesData(deck);
    setShowHistory(false);
  };

  return (
    <div className="min-h-screen bg-ag-dark">
      {/* Header */}
      <header className="border-b border-white/10 bg-ag-dark/80 backdrop-blur-md sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-ag-primary to-ag-secondary flex items-center justify-center">
              <Presentation className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-xl font-bold text-white">スライドビルダー</h1>
              <p className="text-xs text-gray-400">AI駆動プレゼンテーション生成</p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            {/* History Button */}
            <button
              onClick={() => setShowHistory(!showHistory)}
              className="flex items-center gap-2 px-4 py-2 bg-ag-surface rounded-lg text-gray-300 hover:text-white hover:bg-white/10 transition-colors"
            >
              <History className="w-4 h-4" />
              <span className="hidden sm:inline">履歴</span>
              {savedDecks.length > 0 && (
                <span className="bg-ag-primary text-white text-xs px-2 py-0.5 rounded-full">
                  {savedDecks.length}
                </span>
              )}
            </button>

            {/* User indicator */}
            <div className="flex items-center gap-2 px-3 py-2 bg-ag-surface rounded-lg">
              <User className="w-4 h-4 text-gray-400" />
              <span className="text-sm text-gray-400">
                {user ? 'ゲスト' : '未接続'}
              </span>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 py-8">
        <AnimatePresence mode="wait">
          {slidesData ? (
            <motion.div
              key="preview"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
            >
              <SlidePreview
                slidesData={slidesData}
                onEdit={handleEditSlides}
                onClose={handleClosePreview}
              />
            </motion.div>
          ) : (
            <motion.div
              key="input"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="flex flex-col items-center justify-center min-h-[60vh]"
            >
              {/* Hero Section */}
              <div className="text-center mb-12">
                <motion.div
                  initial={{ scale: 0.9, opacity: 0 }}
                  animate={{ scale: 1, opacity: 1 }}
                  transition={{ delay: 0.1 }}
                  className="inline-flex items-center gap-2 px-4 py-2 bg-ag-primary/20 rounded-full text-ag-primary text-sm mb-6"
                >
                  <Sparkles className="w-4 h-4" />
                  RAG搭載 AIスライドジェネレーター
                </motion.div>

                <motion.h2
                  initial={{ y: 20, opacity: 0 }}
                  animate={{ y: 0, opacity: 1 }}
                  transition={{ delay: 0.2 }}
                  className="text-4xl md:text-5xl font-bold mb-4"
                >
                  <span className="gradient-text">プレゼンテーション</span>
                  <br />
                  <span className="text-white">を自動生成</span>
                </motion.h2>

                <motion.p
                  initial={{ y: 20, opacity: 0 }}
                  animate={{ y: 0, opacity: 1 }}
                  transition={{ delay: 0.3 }}
                  className="text-gray-400 text-lg max-w-xl mx-auto"
                >
                  ファイルをアップロードし、プロンプトを入力するだけで
                  高品質なスライドを自動生成します
                </motion.p>
              </div>

              {/* Chat Interface */}
              <motion.div
                initial={{ y: 20, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                transition={{ delay: 0.4 }}
                className="w-full"
              >
                <ChatInterface
                  onGenerate={handleGenerate}
                  isGenerating={isGenerating}
                  generationStatus={generationStatus}
                />
              </motion.div>

              {/* Features */}
              <motion.div
                initial={{ y: 20, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                transition={{ delay: 0.5 }}
                className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-16 w-full max-w-4xl"
              >
                {[
                  {
                    icon: '📄',
                    title: 'RAG対応',
                    description: 'PDF、テキスト、画像を参照してスライド生成'
                  },
                  {
                    icon: '🎨',
                    title: 'Anti-Gravityスタイル',
                    description: '洗練されたデザインを自動適用'
                  },
                  {
                    icon: '📊',
                    title: '図表自動生成',
                    description: 'データからグラフや表を自動作成'
                  }
                ].map((feature, index) => (
                  <div
                    key={index}
                    className="bg-ag-surface/50 rounded-xl p-6 border border-white/5 hover:border-ag-primary/30 transition-colors"
                  >
                    <div className="text-3xl mb-3">{feature.icon}</div>
                    <h3 className="text-white font-semibold mb-2">{feature.title}</h3>
                    <p className="text-gray-400 text-sm">{feature.description}</p>
                  </div>
                ))}
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>
      </main>

      {/* History Sidebar */}
      <AnimatePresence>
        {showHistory && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowHistory(false)}
              className="fixed inset-0 bg-black/50 z-40"
            />
            <motion.div
              initial={{ x: '100%' }}
              animate={{ x: 0 }}
              exit={{ x: '100%' }}
              className="fixed right-0 top-0 bottom-0 w-80 bg-ag-surface border-l border-white/10 z-50 overflow-y-auto"
            >
              <div className="p-4 border-b border-white/10 flex items-center justify-between">
                <h3 className="text-lg font-semibold text-white">履歴</h3>
                <button
                  onClick={() => setShowHistory(false)}
                  className="p-2 rounded-lg hover:bg-white/10 text-gray-400"
                >
                  ×
                </button>
              </div>
              <div className="p-4 space-y-3">
                {savedDecks.length === 0 ? (
                  <p className="text-gray-400 text-center py-8">
                    履歴がありません
                  </p>
                ) : (
                  savedDecks.map((deck) => (
                    <button
                      key={deck.id}
                      onClick={() => loadDeck(deck)}
                      className="w-full text-left p-4 bg-ag-dark rounded-xl hover:bg-white/5 transition-colors"
                    >
                      <h4 className="text-white font-medium truncate">
                        {deck.title || 'プレゼンテーション'}
                      </h4>
                      <p className="text-sm text-gray-400 mt-1">
                        {deck.slides?.length || 0}枚 • {deck.targetAudience || '一般'}
                      </p>
                      <p className="text-xs text-gray-500 mt-1">
                        {deck.createdAt ? new Date(deck.createdAt.seconds * 1000 || deck.createdAt).toLocaleDateString('ja-JP') : ''}
                      </p>
                    </button>
                  ))
                )}
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>

      {/* Footer */}
      <footer className="border-t border-white/10 py-6 mt-auto">
        <div className="max-w-7xl mx-auto px-4 text-center text-gray-500 text-sm">
          <p>スライドビルダー © 2024 Anti-Gravity</p>
          <p className="mt-1">Powered by Gemini API</p>
        </div>
      </footer>
    </div>
  );
}

export default App;
