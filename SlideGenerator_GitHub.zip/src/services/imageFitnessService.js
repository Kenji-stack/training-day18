// Image Fitness Service - Calculate fitness scores for image-slide matching
// Uses semantic analysis, text similarity, and visual quality scoring

const API_KEY = import.meta.env.VITE_GEMINI_API_KEY;
const MODEL_NAME = 'gemini-2.0-flash-exp';
const API_URL = `https://generativelanguage.googleapis.com/v1beta/models/${MODEL_NAME}:generateContent`;

/**
 * 適合度スコアの重み付け
 */
const WEIGHTS = {
    semantic: 0.5,    // セマンティック分析 50%
    textSimilarity: 0.3,  // テキスト類似度 30%
    quality: 0.2      // ビジュアル品質 20%
};

/**
 * 画像とスライドの適合度スコアを計算
 * @param {string} imageUrl - 画像URL
 * @param {Object} slideContent - スライド情報 {title, content, type}
 * @returns {Promise<{score: number, breakdown: Object}>}
 */
export const calculateFitnessScore = async (imageUrl, slideContent) => {
    try {
        // 並列で各スコアを計算
        const [semanticScore, textScore, qualityScore] = await Promise.all([
            calculateSemanticScore(imageUrl, slideContent),
            calculateTextSimilarity(imageUrl, slideContent),
            calculateQualityScore(imageUrl)
        ]);

        // 重み付き総合スコア
        const totalScore =
            (semanticScore * WEIGHTS.semantic) +
            (textScore * WEIGHTS.textSimilarity) +
            (qualityScore * WEIGHTS.quality);

        return {
            score: Math.round(totalScore),
            breakdown: {
                semantic: semanticScore,
                textSimilarity: textScore,
                quality: qualityScore
            }
        };
    } catch (error) {
        console.error('Fitness score calculation error:', error);
        return {
            score: 50, // デフォルトスコア
            breakdown: { semantic: 50, textSimilarity: 50, quality: 50 }
        };
    }
};

/**
 * Gemini Visionを使用してセマンティック分析スコアを計算
 * @param {string} imageUrl - 画像URL
 * @param {Object} slideContent - スライド情報
 * @returns {Promise<number>} 0-100のスコア
 */
const calculateSemanticScore = async (imageUrl, slideContent) => {
    if (!API_KEY) {
        return 50; // APIキーがない場合はデフォルト値
    }

    try {
        // 画像をBase64に変換
        const imageData = await fetchImageAsBase64(imageUrl);
        if (!imageData) {
            return 50;
        }

        const prompt = `この画像がプレゼンテーションスライドに適しているか評価してください。

スライド情報:
- タイトル: ${slideContent.title || '不明'}
- 内容: ${slideContent.content || '不明'}
- スライドタイプ: ${slideContent.type || '不明'}

以下を0-100で評価し、JSON形式で回答してください:
1. relevance: 画像がスライド内容と関連しているか
2. fitness: プレゼンテーション用途に適しているか
3. clarity: 画像のメッセージが明確か

回答形式: {"relevance": 数値, "fitness": 数値, "clarity": 数値}`;

        const response = await fetch(`${API_URL}?key=${API_KEY}`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                contents: [{
                    parts: [
                        { text: prompt },
                        {
                            inline_data: {
                                mime_type: imageData.mimeType,
                                data: imageData.base64
                            }
                        }
                    ]
                }],
                generationConfig: {
                    temperature: 0.3,
                    maxOutputTokens: 256,
                    responseMimeType: 'application/json'
                }
            })
        });

        if (!response.ok) {
            return 50;
        }

        const data = await response.json();
        const text = data.candidates?.[0]?.content?.parts?.[0]?.text;

        if (text) {
            const scores = JSON.parse(text);
            // 3つのスコアの平均
            return Math.round(
                (scores.relevance + scores.fitness + scores.clarity) / 3
            );
        }
    } catch (error) {
        console.warn('Semantic analysis failed:', error);
    }

    return 50;
};

/**
 * テキスト類似度を計算
 * @param {string} imageUrl - 画像URL（キーワード抽出用）
 * @param {Object} slideContent - スライド情報
 * @returns {Promise<number>} 0-100のスコア
 */
const calculateTextSimilarity = async (imageUrl, slideContent) => {
    // URLからキーワードを抽出（Unsplashの場合）
    const urlKeywords = extractKeywordsFromUrl(imageUrl);

    // スライドからキーワードを抽出
    const slideKeywords = extractKeywordsFromSlide(slideContent);

    if (urlKeywords.length === 0 || slideKeywords.length === 0) {
        return 50;
    }

    // キーワードのマッチ率を計算
    let matchCount = 0;
    for (const urlKw of urlKeywords) {
        for (const slideKw of slideKeywords) {
            if (urlKw.toLowerCase().includes(slideKw.toLowerCase()) ||
                slideKw.toLowerCase().includes(urlKw.toLowerCase())) {
                matchCount++;
                break;
            }
        }
    }

    const matchRate = matchCount / Math.max(urlKeywords.length, 1);
    return Math.round(matchRate * 100);
};

/**
 * 画像の品質スコアを計算
 * @param {string} imageUrl - 画像URL
 * @returns {Promise<number>} 0-100のスコア
 */
const calculateQualityScore = async (imageUrl) => {
    return new Promise((resolve) => {
        const img = new Image();
        img.crossOrigin = 'anonymous';

        img.onload = () => {
            let score = 100;

            // 解像度チェック（推奨: 1280x720以上）
            if (img.width < 640 || img.height < 360) {
                score -= 30; // 低解像度
            } else if (img.width < 1280 || img.height < 720) {
                score -= 10; // 中解像度
            }

            // アスペクト比チェック（推奨: 16:9に近い）
            const aspectRatio = img.width / img.height;
            const idealRatio = 16 / 9;
            const ratioDeviation = Math.abs(aspectRatio - idealRatio) / idealRatio;

            if (ratioDeviation > 0.3) {
                score -= 20; // アスペクト比が大きく異なる
            } else if (ratioDeviation > 0.1) {
                score -= 10;
            }

            resolve(Math.max(0, score));
        };

        img.onerror = () => {
            resolve(50); // 読み込み失敗時はデフォルト
        };

        // タイムアウト
        setTimeout(() => resolve(50), 3000);

        img.src = imageUrl;
    });
};

/**
 * 複数の画像候補から最適な画像を選択
 * @param {string[]} imageUrls - 画像URL候補
 * @param {Object} slideContent - スライド情報
 * @returns {Promise<{url: string, score: number, breakdown: Object}>}
 */
export const selectBestImage = async (imageUrls, slideContent) => {
    if (!imageUrls || imageUrls.length === 0) {
        return null;
    }

    console.log(`適合度評価: ${imageUrls.length}枚の画像候補を分析中...`);

    // 全画像のスコアを計算
    const results = await Promise.all(
        imageUrls.map(async (url) => {
            const { score, breakdown } = await calculateFitnessScore(url, slideContent);
            return { url, score, breakdown };
        })
    );

    // スコア順にソート
    results.sort((a, b) => b.score - a.score);

    console.log('適合度スコア結果:', results.map(r => ({
        url: r.url.substring(0, 50) + '...',
        score: r.score
    })));

    // 最高スコアの画像を返す
    return results[0];
};

/**
 * 画像URLをBase64に変換
 * @param {string} url - 画像URL
 * @returns {Promise<{base64: string, mimeType: string}|null>}
 */
const fetchImageAsBase64 = async (url) => {
    try {
        const response = await fetch(url);
        if (!response.ok) return null;

        const blob = await response.blob();
        const mimeType = blob.type || 'image/jpeg';

        return new Promise((resolve) => {
            const reader = new FileReader();
            reader.onloadend = () => {
                const base64 = reader.result.split(',')[1];
                resolve({ base64, mimeType });
            };
            reader.onerror = () => resolve(null);
            reader.readAsDataURL(blob);
        });
    } catch (error) {
        console.warn('Image fetch failed:', error);
        return null;
    }
};

/**
 * URLからキーワードを抽出
 * @param {string} url - 画像URL
 * @returns {string[]}
 */
const extractKeywordsFromUrl = (url) => {
    try {
        const urlObj = new URL(url);
        // Unsplash URLの場合、クエリパラメータからキーワードを抽出
        const searchParams = urlObj.search;
        if (searchParams) {
            // ?keyword&sig=123 形式からキーワードを抽出
            const keywords = searchParams.replace('?', '').split('&')[0];
            return decodeURIComponent(keywords).split(/[\s,+]+/).filter(k => k.length > 2);
        }
    } catch (error) {
        // URLパースエラーは無視
    }
    return [];
};

/**
 * スライドからキーワードを抽出
 * @param {Object} slideContent - スライド情報
 * @returns {string[]}
 */
const extractKeywordsFromSlide = (slideContent) => {
    const text = [
        slideContent.title || '',
        slideContent.content || ''
    ].join(' ');

    // ストップワードを除外してキーワード抽出
    const stopWords = ['a', 'an', 'the', 'is', 'are', 'was', 'were', 'be', 'been',
        'have', 'has', 'had', 'do', 'does', 'did', 'will', 'would', 'could',
        'should', 'may', 'might', 'must', 'for', 'and', 'or', 'but', 'in', 'on',
        'at', 'to', 'of', 'with', 'by', 'from', 'の', 'は', 'が', 'を', 'に',
        'で', 'と', 'も', 'や', 'など', 'について', 'する', 'ます', 'です'];

    return text
        .toLowerCase()
        .replace(/[^a-z0-9\u3040-\u309f\u30a0-\u30ff\u4e00-\u9faf\s]/g, ' ')
        .split(/\s+/)
        .filter(word => word.length > 1 && !stopWords.includes(word))
        .slice(0, 10);
};

export default {
    calculateFitnessScore,
    selectBestImage
};
