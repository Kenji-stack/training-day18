// Gemini Service - Generate slides using Gemini API
// Supports F3.4 (Structure Optimization) and F3.5 (Auto-insertion)
// Model: gemini-2.0-flash-exp

const API_KEY = import.meta.env.VITE_GEMINI_API_KEY;
const MODEL_NAME = 'gemini-2.0-flash-exp';
const API_URL = `https://generativelanguage.googleapis.com/v1beta/models/${MODEL_NAME}:generateContent`;

/**
 * Generate slides using Gemini API
 * @param {string} prompt - User prompt
 * @param {string} ragContext - RAG context from files
 * @param {File[]} images - Image files for vision processing
 * @param {number} slideCount - Target slide count
 * @param {string} targetAudience - Target audience
 * @returns {Promise<GeneratedSlides>} Generated slides data
 */
export const generateSlides = async (
    prompt,
    ragContext = '',
    images = [],
    slideCount = 5,
    targetAudience = '一般'
) => {
    if (!API_KEY) {
        throw new Error('Gemini APIキーが設定されていません');
    }

    const systemPrompt = `あなたはプロフェッショナルなプレゼンテーションデザイナーです。
ユーザーの指示と提供された資料に基づいて、魅力的で高品質なプレゼンテーションスライドを作成することが目標です。

重要：
- ユーザーが指定していないブランド名や製品名を勝手に追加しないでください
- アップロードされた画像やコンテキストに忠実な内容を生成してください
- 「Anti-Gravity」などの固有名詞は使用しないでください

## ターゲットオーディエンス
${targetAudience}

## 目標スライド枚数（必要に応じて調整可能）
${slideCount}枚

## 出力形式
必ず以下のJSON形式で出力してください:
{
  "title": "プレゼンテーションタイトル",
  "slides": [
    {
      "type": "TITLE" | "CONTENT_LEFT" | "CONTENT_RIGHT" | "BULLETS" | "COMPARE" | "STEPS" | "QUOTE",
      "title": "スライドタイトル",
      "content": "メインテキストコンテンツ（箇条書きの場合は\\nで区切る）",
      "imagePrompt": "画像生成用の詳細なプロンプト（英語で、具体的なシーンや要素を記述）",
      "imageKeywords": ["代替キーワード1", "代替キーワード2"],
      "chartData": {
        "type": "BAR_CHART" | "LINE_CHART" | "PIE_CHART" | "FLOW_CHART" | "TABLE",
        "title": "図表タイトル",
        "data": [{"label": "項目1", "value": 100}]
      }
    }
  ]
}

## 画像プロンプトガイドライン
imagePromptフィールドには、スライドの内容に合った画像を生成するための詳細なプロンプトを英語で記述してください。
アップロードされた画像がある場合は、その画像のテーマや雰囲気に合わせてください。

## スライドタイプの説明
- TITLE: タイトルスライド（中央配置、大きなフォント）
- CONTENT_LEFT: コンテンツ左配置、画像右配置
- CONTENT_RIGHT: コンテンツ右配置、画像左配置
- BULLETS: 箇条書きスライド
- COMPARE: 比較スライド（2つの項目を並べて比較）
- STEPS: 手順・ステップスライド
- QUOTE: 引用スライド

## 構成最適化ガイドライン
1. コンテンツの量に応じてスライド枚数を自動調整してください
2. 情報の密度が高い場合はスライドを分割してください
3. コンテンツの性質に応じて適切なスライドタイプを選択してください
4. プレゼンテーションは「イントロ→本編→まとめ」の構成を推奨します

## 図表自動挿入ガイドライン
1. 数値データがある場合は、chartDataフィールドで適切なグラフを指定してください
2. 手順やフローがある場合は、FLOW_CHARTを使用してください
3. 比較データがある場合は、COMPAREタイプまたはTABLEを使用してください

## デザインガイドライン
- プロフェッショナルで洗練されたデザイン
- コンテンツは明確で分かりやすく
- 各スライドには明確なメッセージを
- 視覚的なインパクトを重視`;

    const userMessage = `
以下のRAGコンテキストとユーザーの指示に基づいて、プレゼンテーションスライドを生成してください。

--- RAGコンテキスト ---
${ragContext || '(なし)'}

--- ユーザーの指示 ---
${prompt}

必ずJSON形式で出力してください。`;

    try {
        // Build request parts
        const parts = [
            { text: systemPrompt },
            { text: userMessage }
        ];

        // Add images if present
        for (const image of images) {
            const base64 = await fileToBase64(image);
            parts.push({
                inline_data: {
                    mime_type: image.type,
                    data: base64
                }
            });
        }

        const response = await fetch(`${API_URL}?key=${API_KEY}`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                contents: [{
                    parts: parts
                }],
                generationConfig: {
                    temperature: 0.7,
                    maxOutputTokens: 8192,
                    responseMimeType: 'application/json'
                }
            })
        });

        if (!response.ok) {
            const error = await response.json();
            throw new Error(error.error?.message || 'スライド生成に失敗しました');
        }

        const data = await response.json();
        const text = data.candidates?.[0]?.content?.parts?.[0]?.text;

        if (!text) {
            throw new Error('APIからの応答が空です');
        }

        // Parse JSON response
        const result = JSON.parse(text);
        return result;

    } catch (error) {
        console.error('Gemini API error:', error);
        throw error;
    }
};

/**
 * Generate an image using Gemini Imagen model
 * @param {string} prompt - Image generation prompt
 * @param {File|null} referenceImage - Optional reference image for style guidance
 * @param {string} referenceDescription - Optional description of reference image
 * @param {number} variationSeed - Optional seed for variation (to ensure different images per slide)
 * @returns {Promise<string>} Base64 image data URL
 */
export const generateImage = async (prompt, referenceImage = null, referenceDescription = '', variationSeed = 0) => {
    if (!API_KEY) {
        return null;
    }

    try {
        // Use Gemini 2.0 Flash for image generation
        const imageGenUrl = `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash-exp-image-generation:generateContent?key=${API_KEY}`;

        // 参照画像がある場合は、インスピレーションとして使用（コピーではなくバリエーション）
        let enhancedPrompt = prompt;
        if (referenceDescription) {
            // バリエーションを生成するための指示を追加
            const variationInstructions = [
                "Use a different camera angle or perspective",
                "Focus on a different aspect or element of the scene",
                "Show a different moment or phase of the activity",
                "Create a variation with different lighting conditions",
                "Include different but thematically related elements"
            ];
            const variationHint = variationInstructions[variationSeed % variationInstructions.length];

            enhancedPrompt = `Create a NEW and UNIQUE image inspired by this theme: "${referenceDescription}"

Requirements for this slide: ${prompt}

IMPORTANT VARIATION INSTRUCTIONS:
- DO NOT copy the reference image exactly
- ${variationHint}
- Maintain the same general theme and atmosphere
- Create an original composition that complements but differs from the reference
- This is slide variation #${variationSeed + 1}, so make it distinctly different from other slides`;
        }

        const parts = [{
            text: `Generate a high-quality, ORIGINAL image for a presentation slide. 
${enhancedPrompt}
The image must be a NEW creation, not a recreation of any reference.
Make it visually striking and suitable for a professional presentation.`
        }];

        const response = await fetch(imageGenUrl, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                contents: [{
                    parts: parts
                }],
                generationConfig: {
                    responseModalities: ["TEXT", "IMAGE"]
                }
            })
        });

        if (!response.ok) {
            console.error('Image generation failed:', await response.text());
            return null;
        }

        const data = await response.json();
        const responseParts = data.candidates?.[0]?.content?.parts || [];

        for (const part of responseParts) {
            if (part.inlineData) {
                return `data:${part.inlineData.mimeType};base64,${part.inlineData.data}`;
            }
        }

        return null;
    } catch (error) {
        console.error('Image generation error:', error);
        return null;
    }
};

/**
 * Describe an image using Gemini Vision
 * @param {File} image - Image file
 * @returns {Promise<string>} Image description
 */
export const describeImage = async (image) => {
    if (!API_KEY) {
        return '';
    }

    try {
        const base64 = await fileToBase64(image);

        const response = await fetch(`${API_URL}?key=${API_KEY}`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                contents: [{
                    parts: [
                        { text: '以下の画像の内容を詳細に説明してください。テキストがある場合は抽出してください。' },
                        {
                            inline_data: {
                                mime_type: image.type,
                                data: base64
                            }
                        }
                    ]
                }],
                generationConfig: {
                    temperature: 0.3,
                    maxOutputTokens: 2048
                }
            })
        });

        if (!response.ok) {
            return '';
        }

        const data = await response.json();
        return data.candidates?.[0]?.content?.parts?.[0]?.text || '';

    } catch (error) {
        console.error('Image description error:', error);
        return '';
    }
};

/**
 * Summarize a chunk of text using Gemini
 * @param {string} text - Text to summarize
 * @returns {Promise<string>} Summary
 */
export const summarizeChunk = async (text) => {
    if (!API_KEY || !text) {
        return '';
    }

    try {
        const response = await fetch(`${API_URL}?key=${API_KEY}`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                contents: [{
                    parts: [{
                        text: `以下のテキストを簡潔に要約してください。重要なポイント、キーワード、主要な概念を抽出してください。

テキスト:
${text}

要約:`
                    }]
                }],
                generationConfig: {
                    temperature: 0.3,
                    maxOutputTokens: 512
                }
            })
        });

        if (!response.ok) {
            return '';
        }

        const data = await response.json();
        return data.candidates?.[0]?.content?.parts?.[0]?.text || '';

    } catch (error) {
        console.error('Summarization error:', error);
        return '';
    }
};

/**
 * Convert file to base64
 * @param {File} file - File to convert
 * @returns {Promise<string>} Base64 string
 */
const fileToBase64 = (file) => {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => {
            const base64 = reader.result.split(',')[1];
            resolve(base64);
        };
        reader.onerror = reject;
        reader.readAsDataURL(file);
    });
};
