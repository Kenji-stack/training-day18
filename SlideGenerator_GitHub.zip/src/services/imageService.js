// Image Service - Generate images for slides using Gemini API
// Uses AI-powered image generation for optimal slide visuals

import { generateImage } from './geminiService';

// フォールバック用
const FALLBACK_ENABLED = true;

/**
 * Generate image for a slide using Gemini Image Generation
 * @param {string} prompt - Image description prompt
 * @param {string} keyword - Search keyword
 * @param {Object} slideContent - Slide content for context {title, content, type}
 * @param {Object} referenceData - Reference image data {image: File, description: string}
 * @param {number} slideIndex - Slide index for variation generation
 * @returns {Promise<string>} Image URL or data URL
 */
export const getSlideImage = async (prompt, keyword = '', slideContent = null, referenceData = null, slideIndex = 0) => {
  console.log('[ImageService] 画像生成開始:', {
    prompt: prompt?.substring(0, 50),
    keyword,
    hasReference: !!referenceData,
    slideIndex
  });

  // スライドコンテンツから最適なプロンプトを生成
  const optimizedPrompt = buildImagePrompt(prompt, keyword, slideContent, referenceData?.description);
  console.log('[ImageService] 最適化されたプロンプト:', optimizedPrompt.substring(0, 100));

  try {
    // Gemini画像生成APIを使用（スライドインデックスをvariation seedとして渡す）
    const generatedImage = await generateImage(
      optimizedPrompt,
      null, // 参照画像はプロンプトで説明するため直接渡さない
      referenceData?.description || '',
      slideIndex // スライドごとに異なる画像を生成
    );

    if (generatedImage) {
      console.log('[ImageService] 画像生成成功 (スライド #' + (slideIndex + 1) + ')');
      return generatedImage;
    }

    console.warn('[ImageService] 画像生成失敗、フォールバックを試行');
  } catch (error) {
    console.error('[ImageService] 画像生成エラー:', error);
  }

  // フォールバック: スタイル付きプレースホルダー
  if (FALLBACK_ENABLED) {
    return getStyledPlaceholder(keyword || extractKeywords(prompt));
  }

  return null;
};

/**
 * Build an optimized prompt for image generation based on slide content
 * @param {string} prompt - Original prompt
 * @param {string} keyword - Keyword
 * @param {Object} slideContent - Slide content
 * @param {string} referenceDescription - Description of reference image
 * @returns {string} Optimized prompt
 */
const buildImagePrompt = (prompt, keyword, slideContent, referenceDescription = '') => {
  let basePrompt = prompt || keyword || '';

  // 参照画像の説明がある場合は優先的に使用
  let referenceNote = '';
  if (referenceDescription) {
    referenceNote = `\nIMPORTANT: Use the uploaded reference image as the primary visual guide. 
The generated image should closely match the style, subject matter, and atmosphere of the reference: "${referenceDescription.substring(0, 200)}"`;
  }

  // スライドコンテンツがある場合は詳細なプロンプトを構築
  if (slideContent) {
    const { title, content, type } = slideContent;

    // スライドタイプに応じたスタイル指示
    const styleGuide = getStyleGuideForSlideType(type);

    // コンテンツからキーワードを抽出
    const contentKeywords = extractKeywords(content || '');

    basePrompt = `${title || ''} ${contentKeywords}`.trim() || basePrompt;

    return `Create a professional presentation image for: "${basePrompt}". 
${styleGuide}${referenceNote}
The image should be high-quality, visually striking, and directly relevant to the topic.`;
  }

  return `Create a professional presentation image for: "${basePrompt}".${referenceNote}
Style: Modern, clean, professional suitable for business presentations.`;
};

/**
 * Get style guide based on slide type
 * @param {string} type - Slide type (TITLE, CONTENT_LEFT, BULLETS, etc.)
 * @returns {string} Style instructions for image generation
 */
const getStyleGuideForSlideType = (type) => {
  const guides = {
    'TITLE': 'Use a bold, impactful visual. The image should be dramatic and set the tone for the presentation. Wide aspect ratio, minimal text overlap areas.',
    'CONTENT_LEFT': 'The image will be on the right side. Create a focused, detailed visual that complements informational content. Vertical or square orientation works well.',
    'CONTENT_RIGHT': 'The image will be on the left side. Create a focused, detailed visual that complements informational content. Vertical or square orientation works well.',
    'BULLETS': 'Create a subtle background or accent image that does not overpower text. Consider abstract patterns or soft imagery.',
    'COMPARE': 'Consider split imagery or contrasting visuals that represent comparison or duality.',
    'STEPS': 'Use imagery suggesting progression, process, or sequential concepts. Arrows, pathways, or numbered elements work well.',
    'QUOTE': 'Create elegant, atmospheric imagery suitable for inspirational quotes. Soft focus, gradient backgrounds, or abstract landscapes.',
  };

  return guides[type] || 'Create a professional, versatile image suitable for business presentations.';
};

/**
 * Extract keywords from text for image prompts
 * @param {string} text - Full text
 * @returns {string} Keywords for prompt
 */
const extractKeywords = (text) => {
  if (!text) return 'professional presentation';

  // ストップワードを除外
  const stopWords = ['a', 'an', 'the', 'is', 'are', 'was', 'were', 'be', 'been', 'being',
    'have', 'has', 'had', 'do', 'does', 'did', 'will', 'would', 'could',
    'should', 'may', 'might', 'must', 'shall', 'can', 'for', 'and', 'or',
    'but', 'in', 'on', 'at', 'to', 'of', 'with', 'by', 'from', 'about',
    'の', 'は', 'が', 'を', 'に', 'で', 'と', 'も', 'や', 'など', 'です', 'ます'];

  const words = text.toLowerCase()
    .replace(/[^a-z0-9\u3040-\u309f\u30a0-\u30ff\u4e00-\u9faf\s]/g, ' ')
    .split(/\s+/)
    .filter(word => word.length > 1 && !stopWords.includes(word));

  // 最初の5つの意味のある単語を返す
  return words.slice(0, 5).join(' ') || 'professional presentation';
};

/**
 * Search for multiple images with suggestions
 * @param {string} prompt - Primary prompt
 * @param {string} keyword - Primary keyword
 * @param {string[]} alternateKeywords - Alternate keywords
 * @returns {Promise<{primary: string, suggestions: string[]}>}
 */
export const searchImagesWithSuggestions = async (prompt, keyword = '', alternateKeywords = []) => {
  const primary = await getSlideImage(prompt, keyword);

  // Get alternate images
  const suggestions = [];
  const allKeywords = [keyword, ...alternateKeywords].filter(k => k);

  for (const kw of allKeywords.slice(0, 3)) {
    const seed = Math.floor(Math.random() * 10000);
    const cleanQuery = encodeURIComponent(kw.slice(0, 50).replace(/[^a-zA-Z0-9\s]/g, ''));
    suggestions.push(`${UNSPLASH_SOURCE}/400x300/?${cleanQuery}&sig=${seed}`);
  }

  return {
    primary,
    suggestions: suggestions.slice(0, 5)
  };
};

/**
 * Get styled placeholder image with Anti-Gravity design
 * @param {string} text - Text for placeholder
 * @returns {string} SVG data URL
 */
export const getStyledPlaceholder = (text) => {
  const shortText = (text || 'Slide').slice(0, 30);

  // Create SVG placeholder with Anti-Gravity style
  const svg = `
    <svg xmlns="http://www.w3.org/2000/svg" width="1280" height="720" viewBox="0 0 1280 720">
      <defs>
        <linearGradient id="bg" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" style="stop-color:#0f172a"/>
          <stop offset="100%" style="stop-color:#1e293b"/>
        </linearGradient>
        <linearGradient id="accent" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" style="stop-color:#8b5cf6"/>
          <stop offset="100%" style="stop-color:#ec4899"/>
        </linearGradient>
        <filter id="glow">
          <feGaussianBlur stdDeviation="3" result="coloredBlur"/>
          <feMerge>
            <feMergeNode in="coloredBlur"/>
            <feMergeNode in="SourceGraphic"/>
          </feMerge>
        </filter>
      </defs>
      <rect width="100%" height="100%" fill="url(#bg)"/>
      <!-- Decorative circles -->
      <circle cx="640" cy="360" r="200" fill="none" stroke="url(#accent)" stroke-width="1" opacity="0.2"/>
      <circle cx="640" cy="360" r="150" fill="none" stroke="url(#accent)" stroke-width="1" opacity="0.3"/>
      <circle cx="640" cy="360" r="100" fill="url(#accent)" opacity="0.1"/>
      <!-- Decorative lines -->
      <line x1="100" y1="360" x2="440" y2="360" stroke="url(#accent)" stroke-width="2" opacity="0.3"/>
      <line x1="840" y1="360" x2="1180" y2="360" stroke="url(#accent)" stroke-width="2" opacity="0.3"/>
      <!-- Center icon -->
      <g filter="url(#glow)">
        <circle cx="640" cy="340" r="40" fill="url(#accent)" opacity="0.5"/>
        <path d="M625 340 L640 325 L655 340 L640 355 Z" fill="white" opacity="0.8"/>
      </g>
      <!-- Text -->
      <text x="640" y="420" font-family="Inter, sans-serif" font-size="20" fill="#94a3b8" text-anchor="middle">
        ${escapeXml(shortText)}
      </text>
    </svg>
  `;

  return `data:image/svg+xml;base64,${btoa(unescape(encodeURIComponent(svg)))}`;
};

/**
 * Get simple placeholder image URL
 * @param {string} text - Text for placeholder
 * @returns {string} Placeholder image URL
 */
export const getPlaceholderImage = (text) => {
  const encodedText = encodeURIComponent((text || 'Slide').slice(0, 30));
  return `https://placehold.co/1280x720/1e293b/8b5cf6?text=${encodedText}`;
};

/**
 * Escape XML special characters
 * @param {string} text - Text to escape
 * @returns {string} Escaped text
 */
const escapeXml = (text) => {
  return text
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&apos;');
};
