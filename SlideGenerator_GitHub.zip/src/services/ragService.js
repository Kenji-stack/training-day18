// RAG Service - Extract text from various file formats
// Enhanced with chunk summarization and hierarchical chunking
import * as pdfjsLib from 'pdfjs-dist';
import { summarizeChunk } from './geminiService';

// Set up PDF.js worker
pdfjsLib.GlobalWorkerOptions.workerSrc = `https://cdnjs.cloudflare.com/ajax/libs/pdf.js/${pdfjsLib.version}/pdf.worker.min.js`;

// Chunk configuration
const CHUNK_SIZE = 1000; // characters per chunk
const CHUNK_OVERLAP = 200; // overlap between chunks
const MAX_CHUNKS_PER_LEVEL = 5; // max chunks before creating hierarchy

/**
 * Chunk data structure
 * @typedef {Object} Chunk
 * @property {string} id - Unique chunk ID
 * @property {string} content - Chunk content
 * @property {string} summary - Chunk summary
 * @property {number} level - Hierarchy level (0 = leaf, higher = parent)
 * @property {string[]} childIds - Child chunk IDs
 * @property {Object} metadata - Additional metadata
 */

/**
 * Extract text from a file
 * @param {File} file - Uploaded file
 * @returns {Promise<{text: string, type: string}>} Extracted text and file type
 */
export const extractTextFromFile = async (file) => {
    const fileType = file.type;
    const fileName = file.name.toLowerCase();

    // Text files
    if (fileType === 'text/plain' || fileName.endsWith('.txt')) {
        return {
            text: await extractTextFromText(file),
            type: 'text'
        };
    }

    // Markdown files
    if (fileType === 'text/markdown' || fileName.endsWith('.md')) {
        return {
            text: await extractTextFromText(file),
            type: 'markdown'
        };
    }

    // PDF files
    if (fileType === 'application/pdf' || fileName.endsWith('.pdf')) {
        return {
            text: await extractTextFromPDF(file),
            type: 'pdf'
        };
    }

    // Image files - return file for Gemini processing
    if (fileType.startsWith('image/') || /\.(jpg|jpeg|png|gif|webp|bmp)$/i.test(fileName)) {
        return {
            file: file,
            type: 'image',
            text: '' // Will be processed by Gemini
        };
    }

    throw new Error(`サポートされていないファイル形式です: ${fileType || fileName}`);
};

/**
 * Extract text from text file
 * @param {File} file - Text file
 * @returns {Promise<string>} File content
 */
const extractTextFromText = (file) => {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = (event) => {
            resolve(event.target.result);
        };
        reader.onerror = (error) => {
            reject(new Error('テキストファイルの読み込みに失敗しました'));
        };
        reader.readAsText(file);
    });
};

/**
 * Extract text from PDF file
 * @param {File} file - PDF file
 * @returns {Promise<string>} Extracted text
 */
const extractTextFromPDF = async (file) => {
    try {
        const arrayBuffer = await file.arrayBuffer();
        const pdf = await pdfjsLib.getDocument({ data: arrayBuffer }).promise;

        let fullText = '';

        for (let i = 1; i <= pdf.numPages; i++) {
            const page = await pdf.getPage(i);
            const textContent = await page.getTextContent();
            const pageText = textContent.items
                .map(item => item.str)
                .join(' ');
            fullText += pageText + '\n\n';
        }

        return fullText.trim();
    } catch (error) {
        console.error('PDF extraction error:', error);
        throw new Error('PDFの解析に失敗しました');
    }
};

/**
 * Split text into overlapping chunks
 * @param {string} text - Text to split
 * @param {number} chunkSize - Size of each chunk
 * @param {number} overlap - Overlap between chunks
 * @returns {string[]} Array of text chunks
 */
const splitIntoChunks = (text, chunkSize = CHUNK_SIZE, overlap = CHUNK_OVERLAP) => {
    const chunks = [];
    let start = 0;

    while (start < text.length) {
        let end = start + chunkSize;

        // Try to find a natural break point (sentence end, paragraph)
        if (end < text.length) {
            const searchEnd = Math.min(end + 100, text.length);
            const searchText = text.slice(end, searchEnd);

            // Look for sentence endings
            const breakPoints = ['. ', '。', '\n\n', '\n', '! ', '? '];
            for (const bp of breakPoints) {
                const bpIndex = searchText.indexOf(bp);
                if (bpIndex !== -1) {
                    end = end + bpIndex + bp.length;
                    break;
                }
            }
        }

        chunks.push(text.slice(start, end).trim());
        start = end - overlap;

        if (start >= text.length) break;
    }

    return chunks.filter(c => c.length > 0);
};

/**
 * Create hierarchical chunks with summaries
 * @param {string[]} textChunks - Array of text chunks
 * @param {string} fileName - Source file name
 * @returns {Promise<Chunk[]>} Hierarchical chunk structure
 */
const createHierarchicalChunks = async (textChunks, fileName) => {
    const chunks = [];

    // Level 0: Leaf chunks with summaries
    const leafChunks = await Promise.all(
        textChunks.map(async (content, index) => {
            const id = `${fileName}-L0-${index}`;
            let summary = '';

            // Summarize chunk using Gemini
            try {
                summary = await summarizeChunk(content);
            } catch (e) {
                console.warn('Failed to summarize chunk:', e);
                // Create simple summary from first 100 chars
                summary = content.slice(0, 100) + '...';
            }

            return {
                id,
                content,
                summary,
                level: 0,
                childIds: [],
                metadata: {
                    fileName,
                    chunkIndex: index,
                    charCount: content.length
                }
            };
        })
    );

    chunks.push(...leafChunks);

    // Create hierarchy if there are many chunks
    if (leafChunks.length > MAX_CHUNKS_PER_LEVEL) {
        const parentChunks = await createParentChunks(leafChunks, fileName, 1);
        chunks.push(...parentChunks);
    }

    return chunks;
};

/**
 * Create parent chunks by grouping and summarizing child chunks
 * @param {Chunk[]} childChunks - Child chunks to group
 * @param {string} fileName - Source file name
 * @param {number} level - Current hierarchy level
 * @returns {Promise<Chunk[]>} Parent chunks
 */
const createParentChunks = async (childChunks, fileName, level) => {
    const parentChunks = [];
    const groupSize = MAX_CHUNKS_PER_LEVEL;

    for (let i = 0; i < childChunks.length; i += groupSize) {
        const group = childChunks.slice(i, i + groupSize);
        const groupSummaries = group.map(c => c.summary).join('\n\n');
        const childIds = group.map(c => c.id);

        const id = `${fileName}-L${level}-${Math.floor(i / groupSize)}`;

        let summary = '';
        try {
            summary = await summarizeChunk(groupSummaries);
        } catch (e) {
            summary = groupSummaries.slice(0, 200) + '...';
        }

        parentChunks.push({
            id,
            content: groupSummaries,
            summary,
            level,
            childIds,
            metadata: {
                fileName,
                groupIndex: Math.floor(i / groupSize),
                childCount: group.length
            }
        });
    }

    // Recursively create higher levels if needed
    if (parentChunks.length > MAX_CHUNKS_PER_LEVEL) {
        const higherChunks = await createParentChunks(parentChunks, fileName, level + 1);
        return [...parentChunks, ...higherChunks];
    }

    return parentChunks;
};

/**
 * Build context from hierarchical chunks
 * @param {Chunk[]} chunks - All chunks
 * @returns {string} Formatted context string
 */
const buildContextFromChunks = (chunks) => {
    // Get top-level summaries first
    const maxLevel = Math.max(...chunks.map(c => c.level));
    const topLevelChunks = chunks.filter(c => c.level === maxLevel);

    let context = '## 文書の概要\n';
    topLevelChunks.forEach(chunk => {
        context += chunk.summary + '\n\n';
    });

    // Add detailed content from leaf chunks
    context += '\n## 詳細コンテンツ\n';
    const leafChunks = chunks.filter(c => c.level === 0);
    leafChunks.forEach(chunk => {
        context += `### セクション ${chunk.metadata.chunkIndex + 1}\n`;
        context += `要約: ${chunk.summary}\n\n`;
        context += chunk.content + '\n\n---\n\n';
    });

    return context;
};

/**
 * Process multiple files and combine context with hierarchical chunking
 * @param {File[]} files - Array of files
 * @param {boolean} enableHierarchy - Whether to use hierarchical chunks
 * @returns {Promise<{context: string, images: File[], chunks: Chunk[]}>} Combined context, images, and chunks
 */
export const processFilesForRAG = async (files, enableHierarchy = true) => {
    const allChunks = [];
    const images = [];
    const results = [];

    for (const file of files) {
        try {
            const result = await extractTextFromFile(file);

            if (result.type === 'image') {
                images.push(file);
            } else if (result.text) {
                if (enableHierarchy && result.text.length > CHUNK_SIZE) {
                    // Create hierarchical chunks
                    const textChunks = splitIntoChunks(result.text);
                    const hierarchicalChunks = await createHierarchicalChunks(textChunks, file.name);
                    allChunks.push(...hierarchicalChunks);

                    results.push({
                        fileName: file.name,
                        content: buildContextFromChunks(hierarchicalChunks),
                        type: result.type,
                        chunkCount: hierarchicalChunks.length
                    });
                } else {
                    // Small file, no chunking needed
                    results.push({
                        fileName: file.name,
                        content: result.text,
                        type: result.type,
                        chunkCount: 1
                    });
                }
            }
        } catch (error) {
            console.error(`Error processing file ${file.name}:`, error);
            results.push({
                fileName: file.name,
                content: `[エラー: ${error.message}]`,
                type: 'error',
                chunkCount: 0
            });
        }
    }

    // Build final context string
    const context = results.map(r =>
        `--- ${r.fileName} (${r.type}, ${r.chunkCount} チャンク) ---\n${r.content}`
    ).join('\n\n');

    return { context, images, chunks: allChunks };
};

/**
 * Simple chunk processing without hierarchy (for quick processing)
 * @param {File[]} files - Array of files
 * @returns {Promise<{context: string, images: File[]}>} Combined context and images
 */
export const processFilesSimple = async (files) => {
    const results = [];
    const images = [];

    for (const file of files) {
        try {
            const result = await extractTextFromFile(file);
            if (result.type === 'image') {
                images.push(file);
            } else if (result.text) {
                results.push({
                    fileName: file.name,
                    content: result.text,
                    type: result.type
                });
            }
        } catch (error) {
            console.error(`Error processing file ${file.name}:`, error);
            results.push({
                fileName: file.name,
                content: `[エラー: ${error.message}]`,
                type: 'error'
            });
        }
    }

    const context = results.map(r =>
        `--- ${r.fileName} (${r.type}) ---\n${r.content}`
    ).join('\n\n');

    return { context, images };
};
