// Export Service - Generate PowerPoint files using PptxGenJS
import PptxGenJS from 'pptxgenjs';

// Anti-Gravity color scheme
const COLORS = {
    dark: '0F172A',
    surface: '1E293B',
    primary: '8B5CF6',
    secondary: 'EC4899',
    text: 'FFFFFF',
    textSecondary: 'CBD5E1',
    accent: '06B6D4'
};

/**
 * Export slides to PowerPoint format
 * @param {Object} slidesData - Slides data object
 * @returns {Promise<void>}
 */
export const exportToPPTX = async (slidesData) => {
    const pptx = new PptxGenJS();

    // Set presentation metadata
    pptx.author = 'スライドビルダー';
    pptx.title = slidesData.title || 'プレゼンテーション';
    pptx.subject = 'AI生成プレゼンテーション';
    pptx.company = 'Anti-Gravity';

    // Set default slide size (16:9)
    pptx.defineLayout({ name: 'LAYOUT_16x9', width: 10, height: 5.625 });
    pptx.layout = 'LAYOUT_16x9';

    // Process each slide
    for (const slide of slidesData.slides) {
        await addSlide(pptx, slide);
    }

    // Save file
    const fileName = `${slidesData.title || 'presentation'}_${Date.now()}.pptx`;
    await pptx.writeFile({ fileName });
};

/**
 * Add a single slide to the presentation
 * @param {PptxGenJS} pptx - PptxGenJS instance
 * @param {Object} slide - Slide data
 */
const addSlide = async (pptx, slide) => {
    const pptxSlide = pptx.addSlide();

    // Set dark background
    pptxSlide.background = { color: COLORS.dark };

    // Add content based on slide type
    switch (slide.slideType || slide.type) {
        case 'TITLE':
            addTitleSlide(pptxSlide, slide);
            break;
        case 'CONTENT_LEFT':
            addContentLeftSlide(pptxSlide, slide);
            break;
        case 'CONTENT_RIGHT':
            addContentRightSlide(pptxSlide, slide);
            break;
        case 'BULLETS':
            addBulletsSlide(pptxSlide, slide);
            break;
        case 'COMPARE':
            addCompareSlide(pptxSlide, slide);
            break;
        case 'STEPS':
            addStepsSlide(pptxSlide, slide);
            break;
        case 'QUOTE':
            addQuoteSlide(pptxSlide, slide);
            break;
        default:
            addContentLeftSlide(pptxSlide, slide);
    }
};

/**
 * Add title slide
 */
const addTitleSlide = (pptxSlide, slide) => {
    // Main title
    pptxSlide.addText(slide.slideTitle || slide.title || '', {
        x: 0.5,
        y: 2,
        w: 9,
        h: 1.5,
        fontSize: 44,
        bold: true,
        color: COLORS.text,
        align: 'center',
        valign: 'middle'
    });

    // Subtitle/content
    if (slide.mainContent || slide.content) {
        pptxSlide.addText(slide.mainContent || slide.content || '', {
            x: 1,
            y: 3.8,
            w: 8,
            h: 1,
            fontSize: 20,
            color: COLORS.textSecondary,
            align: 'center',
            valign: 'top'
        });
    }

    // Add gradient decoration
    pptxSlide.addShape('rect', {
        x: 0,
        y: 5.3,
        w: 10,
        h: 0.325,
        fill: { type: 'solid', color: COLORS.primary }
    });
};

/**
 * Add content left slide
 */
const addContentLeftSlide = (pptxSlide, slide) => {
    // Title
    pptxSlide.addText(slide.slideTitle || slide.title || '', {
        x: 0.5,
        y: 0.3,
        w: 9,
        h: 0.7,
        fontSize: 28,
        bold: true,
        color: COLORS.text
    });

    // Content
    const content = slide.mainContent || slide.content || '';
    pptxSlide.addText(content, {
        x: 0.5,
        y: 1.2,
        w: 4.5,
        h: 3.8,
        fontSize: 16,
        color: COLORS.textSecondary,
        valign: 'top',
        paraSpaceAfter: 8
    });

    // Image
    if (slide.imageUrl) {
        try {
            pptxSlide.addImage({
                path: slide.imageUrl,
                x: 5.2,
                y: 1.2,
                w: 4.3,
                h: 3.8,
                sizing: { type: 'cover', w: 4.3, h: 3.8 }
            });
        } catch (e) {
            // Add placeholder if image fails
            addImagePlaceholder(pptxSlide, 5.2, 1.2, 4.3, 3.8);
        }
    }
};

/**
 * Add content right slide
 */
const addContentRightSlide = (pptxSlide, slide) => {
    // Title
    pptxSlide.addText(slide.slideTitle || slide.title || '', {
        x: 0.5,
        y: 0.3,
        w: 9,
        h: 0.7,
        fontSize: 28,
        bold: true,
        color: COLORS.text
    });

    // Image
    if (slide.imageUrl) {
        try {
            pptxSlide.addImage({
                path: slide.imageUrl,
                x: 0.5,
                y: 1.2,
                w: 4.3,
                h: 3.8,
                sizing: { type: 'cover', w: 4.3, h: 3.8 }
            });
        } catch (e) {
            addImagePlaceholder(pptxSlide, 0.5, 1.2, 4.3, 3.8);
        }
    }

    // Content
    const content = slide.mainContent || slide.content || '';
    pptxSlide.addText(content, {
        x: 5,
        y: 1.2,
        w: 4.5,
        h: 3.8,
        fontSize: 16,
        color: COLORS.textSecondary,
        valign: 'top',
        paraSpaceAfter: 8
    });
};

/**
 * Add bullets slide
 */
const addBulletsSlide = (pptxSlide, slide) => {
    // Title
    pptxSlide.addText(slide.slideTitle || slide.title || '', {
        x: 0.5,
        y: 0.3,
        w: 9,
        h: 0.7,
        fontSize: 28,
        bold: true,
        color: COLORS.text
    });

    // Bullet points
    const content = slide.mainContent || slide.content || '';
    const bullets = content.split('\n').filter(b => b.trim());

    const bulletTexts = bullets.map(text => ({
        text: text.replace(/^[-•]\s*/, ''),
        options: {
            bullet: { type: 'bullet', color: COLORS.primary },
            color: COLORS.textSecondary,
            fontSize: 18,
            paraSpaceAfter: 12
        }
    }));

    pptxSlide.addText(bulletTexts, {
        x: 0.5,
        y: 1.2,
        w: 9,
        h: 4,
        valign: 'top'
    });
};

/**
 * Add compare slide (F3.4.1)
 */
const addCompareSlide = (pptxSlide, slide) => {
    // Title
    pptxSlide.addText(slide.slideTitle || slide.title || '', {
        x: 0.5,
        y: 0.3,
        w: 9,
        h: 0.7,
        fontSize: 28,
        bold: true,
        color: COLORS.text
    });

    const content = slide.mainContent || slide.content || '';
    const parts = content.split('\n\n');

    // Left comparison box
    pptxSlide.addShape('roundRect', {
        x: 0.5,
        y: 1.2,
        w: 4.3,
        h: 3.8,
        fill: { color: COLORS.surface },
        line: { color: COLORS.primary, width: 2 }
    });

    pptxSlide.addText(parts[0] || '', {
        x: 0.7,
        y: 1.4,
        w: 3.9,
        h: 3.4,
        fontSize: 14,
        color: COLORS.textSecondary,
        valign: 'top'
    });

    // Right comparison box
    pptxSlide.addShape('roundRect', {
        x: 5.2,
        y: 1.2,
        w: 4.3,
        h: 3.8,
        fill: { color: COLORS.surface },
        line: { color: COLORS.secondary, width: 2 }
    });

    pptxSlide.addText(parts[1] || '', {
        x: 5.4,
        y: 1.4,
        w: 3.9,
        h: 3.4,
        fontSize: 14,
        color: COLORS.textSecondary,
        valign: 'top'
    });

    // VS indicator
    pptxSlide.addText('VS', {
        x: 4.5,
        y: 2.6,
        w: 1,
        h: 0.5,
        fontSize: 20,
        bold: true,
        color: COLORS.accent,
        align: 'center'
    });
};

/**
 * Add steps slide (F3.4.1)
 */
const addStepsSlide = (pptxSlide, slide) => {
    // Title
    pptxSlide.addText(slide.slideTitle || slide.title || '', {
        x: 0.5,
        y: 0.3,
        w: 9,
        h: 0.7,
        fontSize: 28,
        bold: true,
        color: COLORS.text
    });

    const content = slide.mainContent || slide.content || '';
    const steps = content.split('\n').filter(s => s.trim());

    steps.forEach((step, index) => {
        const y = 1.2 + index * 0.8;

        // Step number circle
        pptxSlide.addShape('ellipse', {
            x: 0.5,
            y: y,
            w: 0.5,
            h: 0.5,
            fill: { color: COLORS.primary }
        });

        pptxSlide.addText((index + 1).toString(), {
            x: 0.5,
            y: y,
            w: 0.5,
            h: 0.5,
            fontSize: 16,
            bold: true,
            color: COLORS.text,
            align: 'center',
            valign: 'middle'
        });

        // Step text
        pptxSlide.addText(step.replace(/^\d+\.\s*/, ''), {
            x: 1.2,
            y: y,
            w: 8.3,
            h: 0.6,
            fontSize: 16,
            color: COLORS.textSecondary,
            valign: 'middle'
        });
    });
};

/**
 * Add quote slide (F3.4.1)
 */
const addQuoteSlide = (pptxSlide, slide) => {
    const content = slide.mainContent || slide.content || '';

    // Quote decoration
    pptxSlide.addText('"', {
        x: 0.5,
        y: 0.8,
        w: 1,
        h: 1.5,
        fontSize: 120,
        color: COLORS.primary,
        fontFace: 'Georgia'
    });

    // Quote text
    pptxSlide.addText(content, {
        x: 1.5,
        y: 1.5,
        w: 7,
        h: 2.5,
        fontSize: 24,
        italic: true,
        color: COLORS.text,
        align: 'center',
        valign: 'middle'
    });

    // Author/source
    if (slide.slideTitle || slide.title) {
        pptxSlide.addText(`— ${slide.slideTitle || slide.title}`, {
            x: 1.5,
            y: 4.2,
            w: 7,
            h: 0.5,
            fontSize: 16,
            color: COLORS.textSecondary,
            align: 'center'
        });
    }
};

/**
 * Add image placeholder
 */
const addImagePlaceholder = (pptxSlide, x, y, w, h) => {
    pptxSlide.addShape('rect', {
        x, y, w, h,
        fill: { color: COLORS.surface },
        line: { color: COLORS.primary, width: 1, dashType: 'dash' }
    });

    pptxSlide.addText('画像', {
        x, y, w, h,
        fontSize: 16,
        color: COLORS.textSecondary,
        align: 'center',
        valign: 'middle'
    });
};
