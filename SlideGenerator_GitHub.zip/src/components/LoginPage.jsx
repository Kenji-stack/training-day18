// Login Page Component - Google Authentication
import { useState } from 'react';
import { signInWithGoogle, signInAnonymouslyUser } from '../lib/firebase';

export const LoginPage = ({ onLoginSuccess }) => {
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState(null);

  const handleGoogleLogin = async () => {
    setIsLoading(true);
    setError(null);

    try {
      const user = await signInWithGoogle();
      if (user) {
        onLoginSuccess(user);
      }
    } catch (err) {
      console.error('Login error:', err);
      setError('ログインに失敗しました。もう一度お試しください。');
    } finally {
      setIsLoading(false);
    }
  };

  const handleAnonymousLogin = async () => {
    setIsLoading(true);
    setError(null);

    try {
      const user = await signInAnonymouslyUser();
      if (user) {
        onLoginSuccess(user);
      }
    } catch (err) {
      console.error('Anonymous login error:', err);
      setError('ゲストログインに失敗しました。');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="login-page">
      <div className="login-container">
        <div className="login-header">
          <div className="logo-icon">
            <svg width="48" height="48" viewBox="0 0 48 48" fill="none" role="img" aria-label="Slide Builder ロゴ">
              <rect width="48" height="48" rx="12" fill="url(#gradient)" />
              <path d="M24 12L32 28H16L24 12Z" fill="white" />
              <path d="M24 20L28 28H20L24 20Z" fill="rgba(0,0,0,0.2)" />
              <defs>
                <linearGradient id="gradient" x1="0" y1="0" x2="48" y2="48">
                  <stop stopColor="#8B5CF6" />
                  <stop offset="1" stopColor="#EC4899" />
                </linearGradient>
              </defs>
            </svg>
          </div>
          <h1 className="login-title">Slide Builder</h1>
          <p className="login-subtitle">AIでプレゼンテーションを作成</p>
        </div>

        <div className="login-content">
          <button
            className="google-login-btn"
            onClick={handleGoogleLogin}
            disabled={isLoading}
            aria-label="Googleアカウントでログイン"
          >
            {isLoading ? (
              <span className="loading-spinner" role="status" aria-label="読み込み中"></span>
            ) : (
              <>
                <svg className="google-icon" viewBox="0 0 24 24" width="20" height="20" aria-hidden="true">
                  <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" />
                  <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" />
                  <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" />
                  <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" />
                </svg>
                <span>Googleでログイン</span>
              </>
            )}
          </button>

          <div className="divider">
            <span>または</span>
          </div>

          <button
            className="guest-login-btn"
            onClick={handleAnonymousLogin}
            disabled={isLoading}
            aria-label="ゲストとして利用"
          >
            ゲストとして利用する
          </button>

          {error && (
            <div className="login-error">
              {error}
            </div>
          )}
        </div>

        <div className="login-footer">
          <p>ログインすることで、利用規約とプライバシーポリシーに同意したものとみなされます。</p>
        </div>
      </div>

      <style>{`
        .login-page {
          min-height: 100vh;
          display: flex;
          align-items: center;
          justify-content: center;
          background: linear-gradient(135deg, #0f172a 0%, #1e293b 50%, #0f172a 100%);
          padding: 1rem;
        }

        .login-container {
          width: 100%;
          max-width: 400px;
          background: rgba(30, 41, 59, 0.8);
          backdrop-filter: blur(20px);
          border-radius: 24px;
          padding: 3rem 2rem;
          border: 1px solid rgba(139, 92, 246, 0.2);
          box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.5);
        }

        .login-header {
          text-align: center;
          margin-bottom: 2rem;
        }

        .logo-icon {
          margin-bottom: 1.5rem;
          display: flex;
          justify-content: center;
        }

        .login-title {
          font-size: 2rem;
          font-weight: 700;
          color: white;
          margin: 0 0 0.5rem 0;
          background: linear-gradient(135deg, #8B5CF6, #EC4899);
          -webkit-background-clip: text;
          -webkit-text-fill-color: transparent;
          background-clip: text;
        }

        .login-subtitle {
          color: #94a3b8;
          margin: 0;
          font-size: 1rem;
        }

        .login-content {
          margin-bottom: 2rem;
          display: flex;
          flex-direction: column;
          gap: 1rem;
        }

        .google-login-btn {
          width: 100%;
          display: flex;
          align-items: center;
          justify-content: center;
          gap: 0.75rem;
          padding: 1rem 1.5rem;
          background: white;
          border: none;
          border-radius: 12px;
          font-size: 1rem;
          font-weight: 600;
          color: #1f2937;
          cursor: pointer;
          transition: all 0.2s ease;
        }

        .google-login-btn:hover:not(:disabled) {
          transform: translateY(-2px);
          box-shadow: 0 10px 25px rgba(0, 0, 0, 0.3);
        }

        .google-login-btn:disabled {
          opacity: 0.7;
          cursor: not-allowed;
        }

        .divider {
          display: flex;
          align-items: center;
          text-align: center;
          color: #64748b;
          font-size: 0.875rem;
        }

        .divider::before,
        .divider::after {
          content: '';
          flex: 1;
          border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        }

        .divider span {
          padding: 0 1rem;
        }

        .guest-login-btn {
          width: 100%;
          padding: 1rem 1.5rem;
          background: rgba(255, 255, 255, 0.1);
          border: 1px solid rgba(255, 255, 255, 0.2);
          border-radius: 12px;
          font-size: 1rem;
          font-weight: 600;
          color: white;
          cursor: pointer;
          transition: all 0.2s ease;
        }

        .guest-login-btn:hover:not(:disabled) {
          background: rgba(255, 255, 255, 0.15);
          transform: translateY(-2px);
        }

        .google-icon {
          flex-shrink: 0;
        }

        .loading-spinner {
          width: 20px;
          height: 20px;
          border: 2px solid #e5e7eb;
          border-top-color: #8B5CF6;
          border-radius: 50%;
          animation: spin 0.8s linear infinite;
        }

        @keyframes spin {
          to { transform: rotate(360deg); }
        }

        .login-error {
          margin-top: 0.5rem;
          padding: 0.75rem 1rem;
          background: rgba(239, 68, 68, 0.1);
          border: 1px solid rgba(239, 68, 68, 0.3);
          border-radius: 8px;
          color: #f87171;
          font-size: 0.875rem;
          text-align: center;
        }

        .login-footer {
          text-align: center;
        }

        .login-footer p {
          color: #64748b;
          font-size: 0.75rem;
          margin: 0;
          line-height: 1.5;
        }
      `}</style>
    </div>
  );
};

export default LoginPage;
